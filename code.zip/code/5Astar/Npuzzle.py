import heapq
from copy import deepcopy

class NPuzzleSolver:
    def __init__(self, initial_board):
        self.size = len(initial_board)
        self.initial_state = self.Node(initial_board)

    class Node:
        def __init__(self, board, parent=None, move=None):
            self.board = board
            self.parent = parent
            self.move = move
            self.g = 0 if parent is None else parent.g + 1
            self.h = self.calculate_heuristic()
            self.blank_pos = self.find_blank()

        def find_blank(self):
            for i in range(len(self.board)):
                for j in range(len(self.board)):
                    if self.board[i][j] == 0:
                        return (i, j)
            return None

        def calculate_heuristic(self):
            h = 0
            n = len(self.board)
            for i in range(n):
                for j in range(n):
                    if self.board[i][j] != 0:
                        goal_row = (self.board[i][j] - 1) // n
                        goal_col = (self.board[i][j] - 1) % n
                        h += abs(i - goal_row) + abs(j - goal_col)
            return h

        def is_goal(self):
            n = len(self.board)
            num = 1
            for i in range(n):
                for j in range(n):
                    if i == n - 1 and j == n - 1:
                        if self.board[i][j] != 0:
                            return False
                    else:
                        if self.board[i][j] != num:
                            return False
                        num += 1
            return True

        def get_neighbors(self):
            neighbors = []
            i, j = self.blank_pos
            moves = [(0, 1), (1, 0), (0, -1), (-1, 0)]

            for di, dj in moves:
                ni, nj = i + di, j + dj
                if 0 <= ni < len(self.board) and 0 <= nj < len(self.board):
                    new_board = deepcopy(self.board)
                    new_board[i][j], new_board[ni][nj] = new_board[ni][nj], new_board[i][j]
                    neighbors.append(NPuzzleSolver.Node(new_board, self, (di, dj)))
            return neighbors

        def __lt__(self, other):
            return (self.g + self.h) < (other.g + other.h)

        def __eq__(self, other):
            return self.board == other.board

        def __hash__(self):
            return hash(tuple(tuple(row) for row in self.board))

        def __str__(self):
            return '\n'.join([' '.join(map(str, row)) for row in self.board])

    def solve(self):
        open_set = []
        heapq.heappush(open_set, self.initial_state)
        closed_set = set()

        while open_set:
            current = heapq.heappop(open_set)

            if current.is_goal():
                path = []
                while current.parent is not None:
                    path.append(current)
                    current = current.parent
                path.append(current)
                path.reverse()
                return path

            closed_set.add(current)

            for neighbor in current.get_neighbors():
                if neighbor in closed_set:
                    continue
                if neighbor not in open_set:
                    heapq.heappush(open_set, neighbor)
                else:
                    for node in open_set:
                        if node == neighbor and node.g > neighbor.g:
                            node.g = neighbor.g
                            node.parent = neighbor.parent
                            heapq.heapify(open_set)
                            break
        return None

def get_user_board():
    size = int(input("Enter the size of the puzzle (e.g., 3 for 3x3): "))
    print("Enter the puzzle row by row (use 0 for the blank):")
    board = []
    for i in range(size):
        while True:
            row_input = input(f"Row {i+1}: ")
            row = list(map(int, row_input.strip().split()))
            if len(row) == size:
                board.append(row)
                break
            else:
                print(f"Row must have exactly {size} elements. Please re-enter.")
    return board

if __name__ == "__main__":
    initial_board = get_user_board()
    solver = NPuzzleSolver(initial_board)
    solution = solver.solve()

    if solution:
        print("\nSolution found in", len(solution)-1, "moves:")
        for i, state in enumerate(solution):
            if i > 0:
                print(f"\nMove {i}: {state.move}")
            print(state)
    else:
        print("No solution found")
        
"""Enter the size of the puzzle (e.g., 3 for 3x3): 3
Enter the puzzle row by row (use 0 for the blank):
Row 1: 1 2 3
Row 2: 4 0 6
Row 3: 7 5 8
"""