import heapq

class RobotNavigator:
    def __init__(self, grid):
        self.grid = grid
        self.rows = len(grid)
        self.cols = len(grid[0]) if self.rows > 0 else 0
        self.start_pos = self.find_position('S')
        self.goal_positions = self.find_all_positions('G')

    def find_position(self, char):
        for i in range(self.rows):
            for j in range(self.cols):
                if self.grid[i][j] == char:
                    return (i, j)
        return None

    def find_all_positions(self, char):
        positions = []
        for i in range(self.rows):
            for j in range(self.cols):
                if self.grid[i][j] == char:
                    positions.append((i, j))
        return positions

    class Node:
        def __init__(self, position, parent=None):
            self.position = position
            self.parent = parent
            self.g = 0 if parent is None else parent.g + 1
            self.h = 0
            self.calculate_heuristic()
            
        def calculate_heuristic(self):
            if not self.parent or not hasattr(self.parent, 'goal_positions'):
                return 0
            min_dist = float('inf')
            for goal in self.parent.goal_positions:
                dist = abs(self.position[0] - goal[0]) + abs(self.position[1] - goal[1])
                if dist < min_dist:
                    min_dist = dist
            self.h = min_dist
        
        def is_goal(self, goal_positions):
            return self.position in goal_positions

        def get_neighbors(self, grid, rows, cols):
            neighbors = []
            i, j = self.position
            moves = [(-1, 0), (1, 0), (0, -1), (0, 1)]
            for di, dj in moves:
                ni, nj = i + di, j + dj
                if 0 <= ni < rows and 0 <= nj < cols and grid[ni][nj] != '#':
                    neighbors.append(self.__class__((ni, nj), self))
            return neighbors

        def __lt__(self, other):
            return (self.g + self.h) < (other.g + other.h)

        def __eq__(self, other):
            return self.position == other.position

        def __hash__(self):
            return hash(self.position)

    def solve(self):
        if not self.start_pos or not self.goal_positions:
            return None
            
        start_node = self.Node(self.start_pos)
        start_node.goal_positions = self.goal_positions
        
        open_set = []
        heapq.heappush(open_set, start_node)
        closed_set = set()
        
        while open_set:
            current = heapq.heappop(open_set)
            
            if current.is_goal(self.goal_positions):
                path = []
                while current.parent is not None:
                    path.append(current.position)
                    current = current.parent
                path.append(current.position)
                path.reverse()
                return path
                
            closed_set.add(current)
            
            for neighbor in current.get_neighbors(self.grid, self.rows, self.cols):
                if neighbor in closed_set:
                    continue
                
                neighbor.goal_positions = self.goal_positions
                neighbor.calculate_heuristic()
                
                if neighbor not in open_set:
                    heapq.heappush(open_set, neighbor)
                else:
                    for node in open_set:
                        if node == neighbor and node.g > neighbor.g:
                            node.g = neighbor.g
                            node.parent = neighbor.parent
                            heapq.heapify(open_set)
                            break
        return None

# ------------------------
# USER INPUT STARTS HERE
# ------------------------

def get_user_grid():
    try:
        rows = int(input("Enter the number of rows: "))
        cols = int(input("Enter the number of columns: "))
        print("Enter the grid row by row (use 'S' for start, 'G' for goal, '.' for open, '#' for obstacle):")
        grid = []
        for i in range(rows):
            while True:
                row = input(f"Row {i+1}: ").split()
                if len(row) != cols:
                    print(f"Please enter exactly {cols} elements.")
                    continue
                grid.append(row)
                break
        return grid
    except ValueError:
        print("Invalid input. Please enter numbers correctly.")
        return None

# Main runner
grid = get_user_grid()
if grid:
    navigator = RobotNavigator(grid)
    path = navigator.solve()
    if path:
        print("\nPath found with", len(path)-1, "moves:")
        for i, pos in enumerate(path):
            print(f"Step {i}: {pos}")
    else:
        print("\nNo path found to the goal.")
"""
Enter the number of rows: 4
Enter the number of columns: 5
Row 1: S . . # .
Row 2: . # . . .
Row 3: . # # . #
Row 4: . . . . G
"""