import heapq

class CityPathFinder:
    def __init__(self, graph):
        self.graph = graph

    class Node:
        def __init__(self, city, parent=None, distance_from_parent=0):
            self.city = city
            self.parent = parent
            self.g = 0 if parent is None else parent.g + distance_from_parent
            self.h = 0

        def calculate_heuristic(self, goal_city, heuristic_table=None):
            self.h = 0

        def get_neighbors(self, graph):
            neighbors = []
            for neighbor, distance in graph[self.city].items():
                neighbors.append(self.__class__(neighbor, self, distance))
            return neighbors

        def __lt__(self, other):
            return (self.g + self.h) < (other.g + other.h)

        def __eq__(self, other):
            return self.city == other.city

        def __hash__(self):
            return hash(self.city)

    def find_shortest_path(self, start_city, goal_city):
        if start_city not in self.graph or goal_city not in self.graph:
            return None, None, 0

        start_node = self.Node(start_city)
        start_node.calculate_heuristic(goal_city)

        open_set = []
        open_set_dict = {}
        heapq.heappush(open_set, start_node)
        open_set_dict[start_city] = start_node
        closed_set = set()

        while open_set:
            current = heapq.heappop(open_set)
            del open_set_dict[current.city]

            if current.city == goal_city:
                path = []
                distances = []
                while current.parent is not None:
                    path.append(current.city)
                    distances.append(current.g - current.parent.g)
                    current = current.parent
                path.append(current.city)
                path.reverse()
                distances.reverse()
                return path, distances, sum(distances)

            closed_set.add(current)

            for neighbor in current.get_neighbors(self.graph):
                if neighbor in closed_set:
                    continue

                neighbor.calculate_heuristic(goal_city)

                if neighbor.city not in open_set_dict:
                    heapq.heappush(open_set, neighbor)
                    open_set_dict[neighbor.city] = neighbor
                else:
                    existing_node = open_set_dict[neighbor.city]
                    if neighbor.g < existing_node.g:
                        open_set.remove(existing_node)
                        heapq.heapify(open_set)
                        heapq.heappush(open_set, neighbor)
                        open_set_dict[neighbor.city] = neighbor

        return None, None, 0


def build_city_graph():
    num_cities = int(input("Enter the number of cities: "))
    city_names = input("Enter city names separated by spaces: ").split()
    city_graph = {city: {} for city in city_names}

    num_connections = int(input("Enter the number of connections: "))
    print("Enter each connection in the format: city1 city2 distance")
    for _ in range(num_connections):
        city1, city2, dist = input().split()
        dist = int(dist)
        city_graph[city1][city2] = dist
        city_graph[city2][city1] = dist  # Assuming undirected graph

    return city_graph


def main():
    city_graph = build_city_graph()
    start = input("Enter the start city: ")
    goal = input("Enter the goal city: ")

    finder = CityPathFinder(city_graph)
    path, distances, total_distance = finder.find_shortest_path(start, goal)

    if path:
        print(f"\nShortest path from {start} to {goal}:")
        for i in range(len(path)-1):
            print(f"{path[i]} --({distances[i]})--> ", end='')
        print(path[-1])
        print(f"Total distance: {total_distance}")
    else:
        print(f"No path found from {start} to {goal}")


if __name__ == "__main__":
    main()
#Enter the number of cities: 6  #
#Enter city names separated by spaces: hyderabad chennai bangalore mumbai delhi kolkata  #
#Enter the number of connections: 7  #
#Enter each connection in the format 'city1 city2 distance':#
#Connection 1: hyderabad chennai 9  #
#Connection 2: chennai bangalore 5  #
#Connection 3: bangalore mumbai 10  #
#Connection 4: mumbai delhi 12  #
#Connection 5: hyderabad mumbai 8  #
#Connection 6: delhi kolkata 15  #
#Connection 7: mumbai kolkata 18  #
#Enter the start city: hyderabad#
#Enter the goal city: kolkata#
