import heapq  # Import heapq module to use a priority queue (min-heap)

def get_graph_input():
    """Function to take graph input from the user."""
    graph = {}
    num_edges = int(input("Enter the number of edges: "))
    
    for _ in range(num_edges):
        city1 = input("Enter the first city: ")
        city2 = input("Enter the second city: ")
        cost = int(input(f"Enter the cost to travel from {city1} to {city2}: "))
        
        if city1 not in graph:
            graph[city1] = []
        if city2 not in graph:
            graph[city2] = []
        
        graph[city1].append((city2, cost))
        graph[city2].append((city1, cost))  # Assuming bidirectional travel

    return graph

def get_heuristics_input():
    """Function to take heuristic input from the user."""
    heuristics = {}
    num_cities = int(input("Enter the number of cities: "))
    
    for _ in range(num_cities):
        city = input("Enter the city name: ")
        heuristic = int(input(f"Enter the heuristic value for {city}: "))
        heuristics[city] = heuristic
    
    return heuristics

def best_first_search_city(graph, heuristics, start, goal):
    """Perform best-first search on the graph to find a path to the goal city."""
    
    # Priority queue initialized with the starting city and its heuristic value
    pq = [(heuristics[start], start)]  # Priority queue stores tuples of (heuristic, city)
    
    visited = set()  # Set to keep track of visited cities to avoid revisiting them
    parent = {start: None}  # Dictionary to track the path from the start city
    
    while pq:  # Continue searching while there are still cities in the priority queue
        h, city = heapq.heappop(pq)  # Pop the city with the lowest heuristic value (best choice)
        print("Visiting:", city)  # Print the current city being visited

        if city == goal:  # If we've reached the goal city, print success and reconstruct the path
            print("Goal reached!")
            path = []
            while city is not None:
                path.append(city)
                city = parent[city]
            print("Path:", path[::-1])  # Reverse the path to show it from start to goal
            return

        visited.add(city)  # Mark the current city as visited

        # Loop through the neighbors of the current city (get its neighbors from the graph)
        for neighbor, _ in graph.get(city, []):
            # If the neighbor hasn't been visited yet, add it to the priority queue with its heuristic
            if neighbor not in visited:
                heapq.heappush(pq, (heuristics[neighbor], neighbor))  # Push neighbor with its heuristic to the queue
                parent[neighbor] = city  # Keep track of the path

def main():
    """Main function to handle user input and execute the search."""
    
    print("Welcome to the Best-First Search Algorithm for City Navigation!")
    
    # Get graph input from the user
    graph = get_graph_input()
    
    # Get heuristic values input from the user
    heuristics = get_heuristics_input()
    
    # Get start and goal cities from the user
    start = input("Enter the start city: ")
    goal = input("Enter the goal city: ")
    
    # Perform the best-first search
    best_first_search_city(graph, heuristics, start, goal)

if __name__ == "__main__":
    main()
"""Enter the first city: A  
Enter the second city: B  
Enter the cost to travel from A to B: 4

Enter the first city: A  
Enter the second city: C  
Enter the cost to travel from A to C: 2

Enter the first city: B  
Enter the second city: D  
Enter the cost to travel from B to D: 5

Enter the first city: C  
Enter the second city: D  
Enter the cost to travel from C to D: 1
Enter the city name: A  
Enter the heuristic value for A: 5

Enter the city name: B  
Enter the heuristic value for B: 3

Enter the city name: C  
Enter the heuristic value for C: 2

Enter the city name: D  
Enter the heuristic value for D: 0
Enter the start city: A  
Enter the goal city: D
"""