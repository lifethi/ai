import tkinter as tk
from tkinter import messagebox
from itertools import permutations

# Correct 5x5 layout matching the visual representation
crossword_layout = [
    ['_', '_', '_', '_', '_'],  # Row 0: APPLE
    ['_', '#', '_', '#', '_'],  # Row 1: P # L # A
    ['_', '_', '_', '_', '_'],  # Row 2: LEARN
    ['_', '#', '_', '#', '_'],  # Row 3: A # N # T
    ['_', '_', '_', '_', '_']   # Row 4: (empty or could be NET/TEN)
]

grid_size = len(crossword_layout)
labels = [[None for _ in range(grid_size)] for _ in range(grid_size)]
word_entries = []

def detect_word_slots():
    slots = []
    
    # Detect horizontal slots
    for i in range(grid_size):
        j = 0
        while j < grid_size:
            if crossword_layout[i][j] == '#':
                j += 1
                continue
            start = j
            while j < grid_size and crossword_layout[i][j] == '_':
                j += 1
            length = j - start
            if length >= 2:  # Minimum word length of 3 (since we count spaces)
                slots.append(('H', i, start, length))
    
    # Detect vertical slots
    for j in range(grid_size):
        i = 0
        while i < grid_size:
            if crossword_layout[i][j] == '#':
                i += 1
                continue
            start = i
            while i < grid_size and crossword_layout[i][j] == '_':
                i += 1
            length = i - start
            if length >= 2:  # Minimum word length of 3
                slots.append(('V', start, j, length))
    
    # Specific slots based on the visual layout
    visual_slots = [
        ('H', 0, 0, 5),  # APPLE (row 0, starting at 0, length 5)
        ('H', 2, 0, 5),  # LEARN (row 2, starting at 0, length 5)
        ('V', 0, 0, 5),   # First vertical column
        ('V', 0, 2, 5),   # Third vertical column
        ('V', 0, 4, 5),   # Fifth vertical column
        ('H', 4, 0, 3),   # NET/TEN in bottom row
    ]
    
    return visual_slots  # Using the visual slots for now

def can_place_word(word, slot, grid):
    direction, row, col, length = slot
    if len(word) != length:
        return False
    
    for i in range(length):
        if direction == 'H':
            r, c = row, col + i
        else:
            r, c = row + i, col
        
        # Check if current cell is blocked
        if crossword_layout[r][c] == '#':
            return False
        
        # Check if cell is empty or matches the word letter
        if grid[r][c] != '' and grid[r][c] != word[i]:
            return False
    
    return True

def place_word(word, slot, grid):
    direction, row, col, length = slot
    placed_positions = []
    
    for i in range(length):
        if direction == 'H':
            r, c = row, col + i
        else:
            r, c = row + i, col
        
        if grid[r][c] == '':
            grid[r][c] = word[i]
            placed_positions.append((r, c))
    
    return placed_positions

def remove_word(positions, grid):
    for r, c in positions:
        grid[r][c] = ''

def solve_crossword(words, slots, grid):
    if not words:
        return True
    
    word = words[0]
    
    for slot in slots:
        if can_place_word(word, slot, grid):
            placed = place_word(word, slot, grid)
            
            if solve_crossword(words[1:], [s for s in slots if s != slot], grid):
                return True
            
            # Backtrack
            remove_word(placed, grid)
    
    return False

def solve():
    user_words = [entry.get().strip().upper() for entry in word_entries if entry.get().strip()]
    
    if len(user_words) < 2:
        messagebox.showerror("Input Error", "Please enter at least 2 words.")
        return
    
    slots = detect_word_slots()
    print(f"Detected slots: {slots}")
    
    # Try all permutations of words to find a solution
    for word_permutation in permutations(user_words):
        grid = [['' if cell == '_' else '#' for cell in row] for row in crossword_layout]
        
        if solve_crossword(list(word_permutation), slots, grid):
            # Update the GUI with the solution
            for i in range(grid_size):
                for j in range(grid_size):
                    if crossword_layout[i][j] == '#':
                        labels[i][j]['text'] = ''
                        labels[i][j]['bg'] = 'black'
                    else:
                        labels[i][j]['text'] = grid[i][j]
                        labels[i][j]['bg'] = 'white'
            return
    
    messagebox.showinfo("Result", "No solution found!")

# GUI setup
root = tk.Tk()
root.title("Crossword Puzzle CSP Solver")

title_label = tk.Label(root, text="Crossword Puzzle CSP Solver", font=("Arial", 14))
title_label.pack(pady=10)

entry_frame = tk.Frame(root)
entry_frame.pack()

tk.Label(entry_frame, text="Enter words (up to 7):", font=("Arial", 12)).pack()

for _ in range(7):
    entry = tk.Entry(entry_frame, font=("Arial", 12))
    entry.pack(pady=2)
    word_entries.append(entry)

grid_frame = tk.Frame(root)
grid_frame.pack(pady=10)

for i in range(grid_size):
    for j in range(grid_size):
        bg_color = 'white' if crossword_layout[i][j] == '_' else 'black'
        labels[i][j] = tk.Label(grid_frame, width=4, height=2, relief='solid',
                                font=('Arial', 12), bg=bg_color)
        labels[i][j].grid(row=i, column=j)

solve_button = tk.Button(root, text="Solve Puzzle", command=solve)
solve_button.pack(pady=10)

root.mainloop()