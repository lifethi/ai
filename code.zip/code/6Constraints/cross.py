import itertools
from collections import defaultdict

class CrosswordSolver:
    def __init__(self):
        self.grid = []
        self.words = []
        self.variables = []  # Word placement locations
        self.domains = {}    # Possible words for each variable
        self.constraints = []  # Overlap constraints
        self.neighbors = defaultdict(list)  # Constraint graph

    def get_user_input(self):
        """Collects crossword grid and words from user"""
        print("\n" + "="*50)
        print("CROSSWORD PUZZLE SOLVER".center(50))
        print("="*50)
        
        print("\nEnter grid (use '.' for empty, '#' for blocked):")
        print("Example 3x3 (2-letter words):\n...\n.#.\n...")
        
        while True:
            self.grid = []
            print("\nEnter your grid (row by row):")
            while True:
                row = input("Enter row (or 'done' to finish): ").strip().upper()
                if row == 'DONE':
                    break
                if not all(c in '.#' for c in row):
                    print("Error: Only use '.' (empty) or '#' (blocked)")
                    continue
                self.grid.append(list(row))
            
            if not self.grid:
                print("Please enter at least one row")
                continue
                
            if len(set(len(row) for row in self.grid)) != 1:
                print("Error: All rows must be same length")
                continue
                
            break

        print("\nEnter words (comma separated):")
        print("Example: ART,ANT,TAR,RAT,TAN")
        while True:
            words_input = input("> ").strip().upper()
            self.words = [word.strip() for word in words_input.split(',') if word.strip()]
            if not self.words:
                print("Please enter valid words")
                continue
            break

    def initialize_csp(self):
        """Set up the CSP problem with variables, domains, and constraints"""
        if not self._find_variables():
            return False
        if not self._initialize_domains():
            return False
        self._find_constraints()
        return True

    def _find_variables(self):
        """Identify all word placement locations (variables)"""
        rows = len(self.grid)
        cols = len(self.grid[0]) if rows > 0 else 0

        # Horizontal words
        for i in range(rows):
            j = 0
            while j < cols:
                if self.grid[i][j] == '#':
                    j += 1
                    continue
                start_j = j
                while j < cols and self.grid[i][j] != '#':
                    j += 1
                if j - start_j >= 2:  # Minimum word length 2
                    self.variables.append(('H', i, start_j, j - start_j))

        # Vertical words
        for j in range(cols):
            i = 0
            while i < rows:
                if self.grid[i][j] == '#':
                    i += 1
                    continue
                start_i = i
                while i < rows and self.grid[i][j] != '#':
                    i += 1
                if i - start_i >= 2:  # Minimum word length 2
                    self.variables.append(('V', start_i, j, i - start_i))

        if not self.variables:
            print("\nError: No valid word placement locations found")
            return False
        return True

    def _initialize_domains(self):
        """Create domains for each variable"""
        length_to_words = defaultdict(list)
        for word in self.words:
            length_to_words[len(word)].append(word)

        for var in self.variables:
            length = var[3]
            if length not in length_to_words:
                print(f"\nError: No words of length {length} available")
                return False
            self.domains[var] = length_to_words[length]
        return True

    def _find_constraints(self):
        """Identify all constraints between variables"""
        for i, (dir1, row1, col1, len1) in enumerate(self.variables):
            for j, (dir2, row2, col2, len2) in enumerate(self.variables[i+1:], i+1):
                if dir1 == dir2:
                    continue  # Parallel words don't overlap
                
                if dir1 == 'H':
                    h_var, v_var = self.variables[i], self.variables[j]
                    h_row, h_col, h_len = row1, col1, len1
                    v_row, v_col, v_len = row2, col2, len2
                else:
                    h_var, v_var = self.variables[j], self.variables[i]
                    h_row, h_col, h_len = row2, col2, len2
                    v_row, v_col, v_len = row1, col1, len1

                if (v_col >= h_col and v_col < h_col + h_len and
                    h_row >= v_row and h_row < v_row + v_len):
                    h_pos = v_col - h_col
                    v_pos = h_row - v_row
                    self.constraints.append((h_var, v_var, h_pos, v_pos))
                    self.neighbors[h_var].append(v_var)
                    self.neighbors[v_var].append(h_var)

    def solve(self):
        """Main solving function using backtracking with inference"""
        if not self.initialize_csp():
            return None

        print("\nVariables:")
        for i, var in enumerate(self.variables):
            print(f"Var {i}: {var} (domain: {self.domains[var]})")
        
        print("\nConstraints:")
        for (var1, var2, pos1, pos2) in self.constraints:
            print(f"{var1}[{pos1}] must equal {var2}[{pos2}]")

        assignment = {}
        return self.backtrack(assignment)

    def backtrack(self, assignment):
        """Backtracking search with AC-3 inference"""
        if len(assignment) == len(self.variables):
            return assignment

        var = self.select_unassigned_variable(assignment)
        for value in self.order_domain_values(var, assignment):
            if self.is_consistent(var, value, assignment):
                assignment[var] = value
                inferences = self.ac3(var, value, assignment)
                if inferences is not None:
                    result = self.backtrack(assignment)
                    if result is not None:
                        return result
                del assignment[var]
                if inferences:
                    for (inf_var, inf_val) in inferences:
                        self.domains[inf_var].append(inf_val)
        return None

    def ac3(self, var, value, assignment):
        """Arc consistency algorithm to prune domains"""
        queue = [(neighbor, var) for neighbor in self.neighbors[var] 
                if neighbor not in assignment]
        inferences = []
        
        while queue:
            (xi, xj) = queue.pop(0)
            if self.revise(xi, xj, assignment, inferences):
                if not self.domains[xi]:
                    # Restore domains if failure
                    for (inf_var, inf_val) in inferences:
                        self.domains[inf_var].append(inf_val)
                    return None
                for xk in self.neighbors[xi]:
                    if xk != xj and xk not in assignment:
                        queue.append((xk, xi))
        return inferences

    def revise(self, xi, xj, assignment, inferences):
        """Revise domain of xi based on constraint with xj"""
        revised = False
        constraint = self.get_constraint(xi, xj)
        if not constraint:
            return False
            
        (xi_pos, xj_pos) = constraint
        for x in self.domains[xi][:]:
            # Check if x has any support in xj's domain
            has_support = any(
                x[xi_pos] == y[xj_pos]
                for y in self.domains[xj]
                if y not in assignment.values()
            )
            if not has_support:
                self.domains[xi].remove(x)
                inferences.append((xi, x))
                revised = True
        return revised

    def get_constraint(self, var1, var2):
        """Get constraint positions between two variables"""
        for (v1, v2, pos1, pos2) in self.constraints:
            if (var1 == v1 and var2 == v2) or (var1 == v2 and var2 == v1):
                return (pos1, pos2) if var1 == v1 else (pos2, pos1)
        return None

    def select_unassigned_variable(self, assignment):
        """Select variable using Minimum Remaining Values heuristic"""
        unassigned = [v for v in self.variables if v not in assignment]
        return min(unassigned, key=lambda v: len(self.domains[v]))

    def order_domain_values(self, var, assignment):
        """Order domain values using Least Constraining Value heuristic"""
        def count_conflicts(value):
            conflicts = 0
            for neighbor in self.neighbors[var]:
                if neighbor in assignment:
                    continue
                (var_pos, neighbor_pos) = self.get_constraint(var, neighbor)
                for neighbor_value in self.domains[neighbor]:
                    if value[var_pos] != neighbor_value[neighbor_pos]:
                        conflicts += 1
            return conflicts
        
        return sorted(self.domains[var], key=count_conflicts)

    def is_consistent(self, var, value, assignment):
        """Check if value assignment is consistent with current assignments"""
        for neighbor in self.neighbors[var]:
            if neighbor not in assignment:
                continue
            (var_pos, neighbor_pos) = self.get_constraint(var, neighbor)
            if value[var_pos] != assignment[neighbor][neighbor_pos]:
                return False
        return True

    def print_solution(self, solution):
        """Print the solved crossword grid"""
        if not solution:
            print("\nNo solution found!")
            print("Possible reasons:")
            print("- Word list doesn't contain words of required lengths")
            print("- No valid word combinations satisfy all constraints")
            return

        # Create empty grid
        rows = len(self.grid)
        cols = len(self.grid[0]) if rows > 0 else 0
        output = [['#' for _ in range(cols)] for _ in range(rows)]
        
        # Fill in the solution
        for (direction, row, col, length), word in solution.items():
            if direction == 'H':
                for i in range(length):
                    output[row][col + i] = word[i]
            else:
                for i in range(length):
                    output[row + i][col] = word[i]
        
        # Print the grid
        print("\nSolved Crossword:")
        for row in output:
            print(' '.join(row))
        
        # Print word assignments
        print("\nWord Placements:")
        for (direction, row, col, _), word in sorted(solution.items()):
            pos_type = "Across" if direction == 'H' else "Down"
            print(f"{pos_type:>6} ({row+1},{col+1}): {word}")

def main():
    solver = CrosswordSolver()
    solver.get_user_input()
    solution = solver.solve()
    solver.print_solution(solution)

if __name__ == "__main__":
    print("Crossword Puzzle Solver - CSP Implementation")
    main()  