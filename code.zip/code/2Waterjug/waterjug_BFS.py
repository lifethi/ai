from collections import deque

def water_jug_bfs(jug1, jug2, target):
    visited = set()
    queue = deque([(0, 0, [])])  # State: (Jug1, Jug2, Path to current state)

    while queue:
        x, y, path = queue.popleft()
        
        # Add the current state to the path
        path = path + [(x, y)]

        # If the target is reached
        if x == target or y == target:
            print("\nSteps to reach the target:")
            for step in path:
                print(f"Jug1: {step[0]}, Jug2: {step[1]}")
            return True

        # Mark the current state as visited
        if (x, y) in visited:
            continue
        visited.add((x, y))

        # Generate all possible states
        queue.append((jug1, y, path))  # Fill Jug1
        queue.append((x, jug2, path))  # Fill Jug2
        queue.append((0, y, path))     # Empty Jug1
        queue.append((x, 0, path))     # Empty Jug2
        queue.append((x - min(x, jug2 - y), y + min(x, jug2 - y), path))  # Pour Jug1 -> Jug2
        queue.append((x + min(y, jug1 - x), y - min(y, jug1 - x), path))  # Pour Jug2 -> Jug1

    print("\nTarget not reachable.")
    return False

# Taking user input
try:
    jug1_capacity = int(input("Enter capacity of Jug 1: "))
    jug2_capacity = int(input("Enter capacity of Jug 2: "))
    target_amount = int(input("Enter target amount: "))

    print("\nBFS Solution:")
    water_jug_bfs(jug1_capacity, jug2_capacity, target_amount)
except ValueError:
    print("Please enter valid integers.")
