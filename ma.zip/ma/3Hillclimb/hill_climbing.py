import numpy as np
import networkx as nx
import matplotlib.pyplot as plt

class EightPuzzle:
    def __init__(self, initial, goal):
        self.initial = np.array(initial)
        self.goal = np.array(goal)
        self.size = 3
        self.graph = nx.DiGraph()  # Directed graph for visualization
        self.node_labels = {}  # Node labels for visualization

    def get_manhattan_distance(self, state):
        """Calculate the Manhattan distance heuristic."""
        distance = 0
        for i in range(self.size):
            for j in range(self.size):
                if state[i][j] != 0:
                    x, y = np.where(self.goal == state[i][j])
                    distance += abs(i - x[0]) + abs(j - y[0])
        return distance

    def get_possible_moves(self, state):
        """Generate possible moves by shifting the blank tile."""
        x, y = np.where(state == 0)
        x, y = x[0], y[0]
        moves = []
        directions = [("UP", -1, 0), ("DOWN", 1, 0), ("LEFT", 0, -1), ("RIGHT", 0, 1)]

        for direction, dx, dy in directions:
            new_x, new_y = x + dx, y + dy
            if 0 <= new_x < self.size and 0 <= new_y < self.size:
                new_state = state.copy()
                new_state[x, y], new_state[new_x, new_y] = new_state[new_x, new_y], new_state[x, y]
                moves.append((new_state, direction))

        return moves

    def hill_climbing(self):
        """Solves the 8-puzzle problem using Hill Climbing and builds the transition graph."""
        current_state = self.initial
        current_cost = self.get_manhattan_distance(current_state)
        path = [(current_state, "START")]

        state_id = 0  # Unique identifier for each state
        parent_id = None  # Track parent for graph
        self.graph.add_node(state_id)
        self.node_labels[state_id] = self.state_to_str(current_state)

        while not np.array_equal(current_state, self.goal):
            moves = self.get_possible_moves(current_state)
            next_state, next_move = min(moves, key=lambda x: self.get_manhattan_distance(x[0]))

            next_cost = self.get_manhattan_distance(next_state)
            if next_cost >= current_cost:  # Stuck at local optimum
                print("\nStuck at local optimum, restarting...\n")
                return None

            state_id += 1
            self.graph.add_node(state_id)
            self.node_labels[state_id] = self.state_to_str(next_state)
            self.graph.add_edge(parent_id, state_id, label=next_move) if parent_id is not None else None
            parent_id = state_id  # Set parent for next iteration

            current_state = next_state
            current_cost = next_cost
            path.append((current_state, next_move))

        return path

    def state_to_str(self, state):
        """Convert the 3x3 puzzle into a string representation for labeling."""
        return "\n".join([" ".join(map(str, row)) for row in state])

    def display_path(self, path):
        """Print the steps from start to goal."""
        if path is None:
            print("Solution not found due to local optimum.")
            return

        for i, (state, move) in enumerate(path):
            print(f"\nStep {i}: {move}")
            print(state)

    def draw_tree(self):
        """Visualizes the search tree of the puzzle solving process."""
        plt.figure(figsize=(10, 6))
        pos = nx.spring_layout(self.graph, seed=42)  # Layout for better positioning
        nx.draw(self.graph, pos, with_labels=True, labels=self.node_labels, node_size=3000, node_color="lightblue", edge_color="gray", font_size=10)
        edge_labels = nx.get_edge_attributes(self.graph, 'label')
        nx.draw_networkx_edge_labels(self.graph, pos, edge_labels=edge_labels)
        plt.title("State Transition Tree - 8 Puzzle (Hill Climbing)")
        plt.show()

if __name__ == "__main__":
    initial_state = [[2, 8, 3], [1, 6, 4], [7, 0, 5]]  # Example random state
    goal_state = [[1, 2, 3], [8, 0, 4], [7, 6, 5]]

    puzzle = EightPuzzle(initial_state, goal_state)
    solution_path = puzzle.hill_climbing()
    puzzle.display_path(solution_path)
    puzzle.draw_tree()
