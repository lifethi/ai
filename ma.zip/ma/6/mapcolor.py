def is_valid_coloring(region, color, assignment, graph):
    """Check if a color is valid for a region."""
    for neighbor in graph[region]:
        if neighbor in assignment and assignment[neighbor] == color:
            return False
    return True


def backtrack(assignment, graph, colors):
    """Backtracking function for map coloring."""
    if len(assignment) == len(graph):
        return assignment

    unassigned = [region for region in graph if region not in assignment][0]
    for color in colors:
        if is_valid_coloring(unassigned, color, assignment, graph):
            assignment[unassigned] = color
            result = backtrack(assignment, graph, colors)
            if result:
                return result
            del assignment[unassigned]
    return None


def map_coloring(graph, colors):
    """Solve the map coloring problem."""
    return backtrack({}, graph, colors)


def main():
    graph = {}
    num_regions = int(input("Enter number of regions: "))
    num_edges = int(input("Enter number of edges: "))

    print("Enter edges (region1 region2):")
    for _ in range(num_edges):
        region1, region2 = input().split()
        graph.setdefault(region1, []).append(region2)
        graph.setdefault(region2, []).append(region1)

    colors = input("Enter colors (comma separated): ").split(", ")
    solution = map_coloring(graph, colors)

    print("\nColor Assignment:")
    if solution:
        for region, color in solution.items():
            print(f"{region}: {color}")
    else:
        print("No valid coloring found.")


if __name__ == "__main__":
    main()
