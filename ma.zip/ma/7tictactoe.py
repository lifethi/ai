import tkinter as tk
from tkinter import messagebox

PLAYER = "X"
AI = "O"

class TicTacToe:
    def __init__(self, root):
        self.root = root
        self.root.title("Tic Tac Toe - Minimax AI")
        self.board = [["" for _ in range(3)] for _ in range(3)]
        self.buttons = [[None for _ in range(3)] for _ in range(3)]
        self.create_widgets()

    def create_widgets(self):
        for i in range(3):
            for j in range(3):
                btn = tk.Button(self.root, text="", font=("Arial", 32), width=5, height=2,
                                command=lambda row=i, col=j: self.on_click(row, col))
                btn.grid(row=i, column=j)
                self.buttons[i][j] = btn

    def on_click(self, row, col):
        if self.board[row][col] == "":
            self.make_move(row, col, PLAYER)
            if not self.check_winner(PLAYER):
                self.ai_move()

    def make_move(self, row, col, player):
        self.board[row][col] = player
        self.buttons[row][col].config(text=player, state="disabled")

        if self.check_winner(player):
            messagebox.showinfo("Game Over", f"{player} wins!")
            self.disable_all_buttons()
        elif self.is_draw():
            messagebox.showinfo("Game Over", "It's a draw!")
            self.disable_all_buttons()

    def ai_move(self):
        best_score = -float("inf")
        best_move = None

        for i in range(3):
            for j in range(3):
                if self.board[i][j] == "":
                    self.board[i][j] = AI
                    score = self.minimax(self.board, 0, False)
                    self.board[i][j] = ""
                    if score > best_score:
                        best_score = score
                        best_move = (i, j)

        if best_move:
            self.make_move(best_move[0], best_move[1], AI)

    def minimax(self, board, depth, is_maximizing):
        if self.check_winner_state(board, AI):
            return 1
        elif self.check_winner_state(board, PLAYER):
            return -1
        elif self.is_draw_state(board):
            return 0

        if is_maximizing:
            best_score = -float("inf")
            for i in range(3):
                for j in range(3):
                    if board[i][j] == "":
                        board[i][j] = AI
                        score = self.minimax(board, depth + 1, False)
                        board[i][j] = ""
                        best_score = max(score, best_score)
            return best_score
        else:
            best_score = float("inf")
            for i in range(3):
                for j in range(3):
                    if board[i][j] == "":
                        board[i][j] = PLAYER
                        score = self.minimax(board, depth + 1, True)
                        board[i][j] = ""
                        best_score = min(score, best_score)
            return best_score

    def check_winner(self, player):
        return self.check_winner_state(self.board, player)

    def check_winner_state(self, board, player):
        for i in range(3):
            if all(board[i][j] == player for j in range(3)) or \
               all(board[j][i] == player for j in range(3)):
                return True
        if board[0][0] == board[1][1] == board[2][2] == player or \
           board[0][2] == board[1][1] == board[2][0] == player:
            return True
        return False

    def is_draw(self):
        return self.is_draw_state(self.board)

    def is_draw_state(self, board):
        return all(cell != "" for row in board for cell in row)

    def disable_all_buttons(self):
        for row in self.buttons:
            for btn in row:
                btn.config(state="disabled")

if __name__ == "__main__":
    root = tk.Tk()
    game = TicTacToe(root)
    root.mainloop()
