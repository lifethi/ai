import heapq  # Import the heapq module to use a priority queue (min-heap)
import copy  # Import the copy module for deep copying lists

# Define the goal state of the puzzle
goal_state = [[1, 2, 3],
              [4, 5, 6],
              [7, 8, 0]]  # 0 represents the empty tile

# Define the possible moves for the empty tile (right, down, left, up)
moves = [(0, 1), (1, 0), (0, -1), (-1, 0)]

def manhattan(state):
    """Calculate the Manhattan distance heuristic for the current state."""
    dist = 0  # Initialize the total Manhattan distance
    for i in range(3):  # Loop over each row
        for j in range(3):  # Loop over each column
            val = state[i][j]  # Get the value at position (i, j)
            if val != 0:  # If it's not the empty tile (0)
                # Calculate the goal position of the tile
                goal_x, goal_y = divmod(val - 1, 3)  # divmod gives row and column in the goal state
                # Add the Manhattan distance to the total
                dist += abs(i - goal_x) + abs(j - goal_y)
    return dist  # Return the total Manhattan distance

def get_neighbors(state):
    """Generate all valid neighboring states by moving the empty tile."""
    neighbors = []  # List to store all valid neighboring states
    # Find the position of the blank tile (0)
    for i in range(3):
        for j in range(3):
            if state[i][j] == 0:
                x, y = i, j  # Store the coordinates of the blank tile

    # Loop through the possible moves (right, down, left, up)
    for dx, dy in moves:
        nx, ny = x + dx, y + dy  # Calculate the new position of the blank tile
        # Check if the new position is within bounds (0 <= nx, ny < 3)
        if 0 <= nx < 3 and 0 <= ny < 3:
            new_state = copy.deepcopy(state)  # Make a deep copy of the current state
            # Swap the blank tile with the adjacent tile
            new_state[x][y], new_state[nx][ny] = new_state[nx][ny], new_state[x][y]
            neighbors.append(new_state)  # Add the new state to the list of neighbors
    return neighbors  # Return the list of neighbors

def print_state(state):
    """Print the current state in a readable format."""
    for row in state:
        print(row)  # Print each row of the state
    print()  # Print a blank line for separation

def best_first_search(start):
    """Perform the best-first search algorithm to find the solution."""
    visited = set()  # Set to keep track of visited states
    pq = []  # Priority queue to store states based on their heuristic value (Manhattan distance)
    
    # Push the initial state to the priority queue with its heuristic value (Manhattan distance)
    heapq.heappush(pq, (manhattan(start), start))

    steps = 0  # Initialize step counter for tracking the number of steps
    while pq:  # While there are still states in the priority queue
        # Pop the state with the lowest heuristic (Manhattan distance) from the queue
        cost, state = heapq.heappop(pq)
        # Convert the state into a tuple (to be hashable) for easy lookup in the visited set
        state_tuple = tuple(tuple(row) for row in state)

        # If the state has already been visited, skip it
        if state_tuple in visited:
            continue
        visited.add(state_tuple)  # Mark this state as visited

        # Print the current step and the cost (Manhattan distance) for this state
        print(f"Step {steps}, Cost (h) = {cost}")
        print_state(state)  # Print the current state
        steps += 1  # Increment the step counter

        # If the goal state is reached, print success message and exit
        if state == goal_state:
            print(" Goal Reached!")
            return

        # Loop through all the valid neighboring states
        for neighbor in get_neighbors(state):
            # Convert the neighbor state into a tuple for easy lookup in the visited set
            neighbor_tuple = tuple(tuple(row) for row in neighbor)
            # If the neighbor hasn't been visited, push it to the priority queue
            if neighbor_tuple not in visited:
                heapq.heappush(pq, (manhattan(neighbor), neighbor))

    # If the priority queue is empty and the goal hasn't been found, print failure message
    print("No solution found.")

# Define the initial state of the puzzle
initial_state = [
    [1, 2, 3],
    [4, 5, 6],
    [0, 7, 8]
]

# Start the best-first search with the initial state
best_first_search(initial_state)
