import heapq  # Import heapq module to use a priority queue (min-heap)

# Sample graph where each node is a city and the edges represent connections between cities with associated costs
graph = {
    'A': [('B', 1), ('C', 3)],  # From A, you can go to B (cost 1) and C (cost 3)
    'B': [('D', 4), ('E', 2)],  # From B, you can go to D (cost 4) and E (cost 2)
    'C': [('F', 5)],  # From C, you can go to F (cost 5)
    'D': [],  # D has no neighbors
    'E': [('G', 1)],  # From E, you can go to G (cost 1)
    'F': [],  # F has no neighbors
    'G': []  # G is the goal, no neighbors
}

# Heuristic values: straight-line distance (or estimated cost) to the goal for each city
heuristics = {
    'A': 7, 'B': 6, 'C': 4, 'D': 6, 'E': 2, 'F': 3, 'G': 0  # G is the goal, so its heuristic is 0
}

def best_first_search_city(start, goal):
    """Perform best-first search on the graph to find a path to the goal city."""
    
    # Priority queue initialized with the starting city and its heuristic value
    pq = [(heuristics[start], start)]  # Priority queue stores tuples of (heuristic, city)
    
    visited = set()  # Set to keep track of visited cities to avoid revisiting them
    
    while pq:  # Continue searching while there are still cities in the priority queue
        h, city = heapq.heappop(pq)  # Pop the city with the lowest heuristic value (best choice)
        print("Visiting:", city)  # Print the current city being visited

        if city == goal:  # If we've reached the goal city, print success and return
            print("Goal reached!")
            return

        visited.add(city)  # Mark the current city as visited

        # Loop through the neighbors of the current city (get its neighbors from the graph)
        for neighbor, _ in graph.get(city, []):
            # If the neighbor hasn't been visited yet, add it to the priority queue with its heuristic
            if neighbor not in visited:
                heapq.heappush(pq, (heuristics[neighbor], neighbor))  # Push neighbor with its heuristic to the queue

# Start the best-first search from city 'A' and look for city 'G' as the goal
best_first_search_city('A', 'G')
