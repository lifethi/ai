import heapq  # Import the heapq module to use a priority queue (min-heap)

def heuristic(a, b):
    """Calculate the Manhattan distance between two points."""
    return abs(a[0] - b[0]) + abs(a[1] - b[1])  # The Manhattan distance is the sum of absolute differences in x and y coordinates

def best_first_search_robot(grid, start, goal):
    """Perform the best-first search algorithm to find the shortest path for a robot from start to goal."""
    
    rows, cols = len(grid), len(grid[0])  # Get the dimensions of the grid (number of rows and columns)
    visited = set()  # A set to keep track of the visited cells (coordinates)
    
    # Initialize the priority queue with the start point and its heuristic value (distance to the goal)
    pq = [(heuristic(start, goal), start)]  # Each item in the priority queue is a tuple (heuristic, position)
    
    while pq:  # While there are still nodes to explore
        # Pop the node with the lowest heuristic value (i.e., the closest to the goal)
        _, current = heapq.heappop(pq)
        print("Visiting:", current)  # Print the current position being visited

        # If the current position is the goal, print success and return
        if current == goal:
            print("Goal reached!")
            return
        
        # Mark the current position as visited
        visited.add(current)
        x, y = current  # Extract the current position's x and y coordinates
        
        # Explore the four possible directions (up, down, left, right)
        for dx, dy in [(-1, 0), (1, 0), (0, -1), (0, 1)]:
            nx, ny = x + dx, y + dy  # Calculate the neighbor's new position

            # Check if the neighbor is within bounds of the grid and is a free space (0)
            if 0 <= nx < rows and 0 <= ny < cols and grid[nx][ny] == 0:
                neighbor = (nx, ny)  # Define the neighbor's coordinates
                if neighbor not in visited:  # If the neighbor hasn't been visited
                    # Push the neighbor to the priority queue with its heuristic value (distance to the goal)
                    heapq.heappush(pq, (heuristic(neighbor, goal), neighbor))

# Define the grid (0 = free space, 1 = obstacle)
grid = [
    [0, 0, 0, 1],  # Row 0: free space, free space, free space, obstacle
    [1, 0, 1, 0],  # Row 1: obstacle, free space, obstacle, free space
    [0, 0, 0, 0],  # Row 2: free space, free space, free space, free space
]

start = (0, 0)  # Starting point (top-left corner)
goal = (2, 3)   # Goal point (bottom-right corner)

# Call the best_first_search_robot function to find the path
best_first_search_robot(grid, start, goal)
