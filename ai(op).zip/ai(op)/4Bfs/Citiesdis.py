from collections import deque

def bfs(graph, start, goal):
    visited = set()
    queue = deque([(start, [start])])  # (current city, path taken)

    while queue:
        city, path = queue.popleft()
        if city == goal:
            return path

        if city not in visited:
            visited.add(city)
            for neighbor in graph[city]:
                if neighbor not in visited:
                    queue.append((neighbor, path + [neighbor]))
    return None

def main():
    graph = {}
    n = int(input("Enter the number of cities: "))

    print("Enter the names of the cities:")
    cities = [input(f"City {i+1}: ").strip() for i in range(n)]

    # Initialize adjacency list
    for city in cities:
        graph[city] = []

    m = int(input("Enter number of connections (edges): "))
    print("Enter each connection (e.g., CityA CityB):")
    for _ in range(m):
        u, v = input().split()
        graph[u].append(v)
        graph[v].append(u)  # Assuming undirected connections

    start = input("Enter the start city: ").strip()
    goal = input("Enter the goal city: ").strip()

    if start not in graph or goal not in graph:
        print("Start or goal city not in the city list.")
        return

    path = bfs(graph, start, goal)
    if path:
        print("Path found using BFS:")
        print(" -> ".join(path))
    else:
        print("No path found.")

if __name__ == "__main__":
    main()
