from itertools import permutations

# Function to convert a word into a number based on the digit assignment
def word_to_number(word, assignment):
    # Convert each character in the word to its assigned digit and join them to form the number
    return int(''.join(str(assignment[char]) for char in word))

# Function to solve the cryptarithmetic puzzle
def solve_cryptarithmetic(word1, word2, result_word):
    # Get all unique letters from the words
    unique_letters = set(word1 + word2 + result_word)
    
    # If there are more than 10 unique letters, it's impossible to assign a unique digit to each one
    if len(unique_letters) > 10:
        print("Too many unique letters (max 10 allowed in base-10 digits).")
        return

    # Create a list of unique letters and a range of digits (0-9)
    letters = list(unique_letters)
    digits = range(10)

    # Try all permutations of digits to assign to the letters
    for perm in permutations(digits, len(letters)):
        # Create a mapping from each letter to a digit
        assignment = dict(zip(letters, perm))

        # Check for leading zeros: the first letter of each word cannot be assigned 0
        if assignment[word1[0]] == 0 or assignment[word2[0]] == 0 or assignment[result_word[0]] == 0:
            continue

        # Convert the words to numbers using the current digit assignment
        num1 = word_to_number(word1, assignment)
        num2 = word_to_number(word2, assignment)
        result = word_to_number(result_word, assignment)

        # If the sum of the first two numbers equals the result, we've found a solution
        if num1 + num2 == result:
            print("Solution:")
            print(assignment)  # Show the digit-letter assignment
            print(f"{word1.upper()} ({num1}) + {word2.upper()} ({num2}) = {result_word.upper()} ({result})")
            return

    # If no solution is found after checking all permutations, print a message
    print("No solution found.")

# Interactive input for the user to provide words
if __name__ == "__main__":
    # Get the three words from the user (convert to uppercase to avoid case sensitivity issues)
    word1 = input("Enter the first word: ").strip().upper()
    word2 = input("Enter the second word: ").strip().upper()
    result_word = input("Enter the result word: ").strip().upper()

    # Call the function to solve the cryptarithmetic puzzle
    solve_cryptarithmetic(word1, word2, result_word)


'''
Enter the first word: SEND
Enter the second word: MORE
Enter the result word: MONEY
Solution:
{'M': 1, 'N': 6, 'R': 8, 'E': 5, 'D': 7, 'Y': 2, 'S': 9, 'O': 0}
SEND (9567) + MORE (1085) = MONEY (10652)
'''