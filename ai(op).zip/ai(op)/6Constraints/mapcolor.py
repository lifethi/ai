def is_valid_coloring(region, color, assignment, graph):
    """Check if a color is valid for a region.
    
    Checks if the region can be assigned the given color without 
    causing a conflict with neighboring regions that have already been assigned colors.
    """
    # Iterate over all the neighbors of the current region
    for neighbor in graph[region]:
        # If the neighbor has been assigned the same color, return False (invalid coloring)
        if neighbor in assignment and assignment[neighbor] == color:
            return False
    return True

def backtrack(assignment, graph, colors):
    """Backtracking function for map coloring.
    
    This function attempts to assign colors to regions using backtracking. If a valid coloring 
    is found that satisfies the graph constraints, it returns the assignment. Otherwise, it 
    backtracks and tries different combinations.
    """
    # If all regions have been assigned a color, return the current assignment
    if len(assignment) == len(graph):
        return assignment

    # Choose an unassigned region (first one not in the assignment)
    unassigned = [region for region in graph if region not in assignment][0]

    # Try each color for the unassigned region
    for color in colors:
        # Check if the color is valid for this region
        if is_valid_coloring(unassigned, color, assignment, graph):
            # Assign the color to the region
            assignment[unassigned] = color
            # Recursively attempt to color the rest of the regions
            result = backtrack(assignment, graph, colors)
            if result:
                return result  # If successful, return the result
            # If no valid coloring is found, remove the color and backtrack
            del assignment[unassigned]

    # If no valid coloring is found, return None
    return None

def map_coloring(graph, colors):
    """Solve the map coloring problem.
    
    This function calls the backtracking solver and returns the solution
    if a valid coloring is found, or None if no solution exists.
    """
    return backtrack({}, graph, colors)

# User input
graph = {}  # Dictionary to store the graph (regions and edges)
num_regions = int(input("Enter number of regions: "))  # Input number of regions
num_edges = int(input("Enter number of edges: "))  # Input number of edges

# Input edges and construct the graph
print("Enter edges (region1 region2):")
for _ in range(num_edges):
    region1, region2 = input().split()  # Each edge connects two regions
    # Add each region to the adjacency list
    graph.setdefault(region1, []).append(region2)
    graph.setdefault(region2, []).append(region1)

# Input available colors
colors = input("Enter colors (comma separated): ").split(", ")

# Call the map_coloring function to solve the problem
solution = map_coloring(graph, colors)

# Print the solution
print("Solution:", solution)
'''
Enter number of regions: 4
Enter number of edges: 4
Enter edges (region1 region2):
A B
A C
B D
C D
Enter colors (comma separated): Red, Green, Blue
'''