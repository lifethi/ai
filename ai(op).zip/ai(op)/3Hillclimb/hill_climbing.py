import copy
import random

GOAL_STATE = [[1, 2, 3], [4, 5, 6], [7, 8, 0]]

def input_puzzle():
    print("Enter the 8-puzzle initial state (use 0 for blank):")
    state = []
    for i in range(3):
        row = list(map(int, input(f"Row {i + 1} (space-separated): ").split()))
        state.append(row)
    return state

def print_state(state):
    for row in state:
        print(' '.join(str(x) for x in row))
    print()

def get_blank_position(state):
    for i in range(3):
        for j in range(3):
            if state[i][j] == 0:
                return i, j

def heuristic(state):
    """Number of misplaced tiles."""
    count = 0
    for i in range(3):
        for j in range(3):
            if state[i][j] != 0 and state[i][j] != GOAL_STATE[i][j]:
                count += 1
    return count

def get_neighbors(state):
    x, y = get_blank_position(state)
    neighbors = []
    moves = [(-1, 0), (1, 0), (0, -1), (0, 1)]  # Up Down Left Right

    for dx, dy in moves:
        new_x, new_y = x + dx, y + dy
        if 0 <= new_x < 3 and 0 <= new_y < 3:
            new_state = copy.deepcopy(state)
            new_state[x][y], new_state[new_x][new_y] = new_state[new_x][new_y], new_state[x][y]
            neighbors.append(new_state)

    return neighbors

def hill_climbing(start):
    current = start
    current_h = heuristic(current)
    steps = 0

    while True:
        neighbors = get_neighbors(current)
        next_state = None
        next_h = current_h

        for neighbor in neighbors:
            h = heuristic(neighbor)
            if h < next_h:
                next_state = neighbor
                next_h = h

        if next_state is None:
            break  # Local minimum

        current = next_state
        current_h = next_h
        steps += 1

        print(f"Step {steps}: (Heuristic = {current_h})")
        print_state(current)

        if current_h == 0:
            print("Goal reached!")
            return

    print("Stuck at local minimum, solution not found.")

if __name__ == "__main__":
    initial_state = input_puzzle()
    print("\nInitial State:")
    print_state(initial_state)
    hill_climbing(initial_state)
