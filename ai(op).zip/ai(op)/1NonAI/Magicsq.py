def generate_magic_square(n):
    if n % 2 == 0:
        print("Only odd-order magic squares are supported.")
        return

    magic_square = [[0]*n for _ in range(n)]
    i, j = 0, n // 2
    num = 1

    while num <= n*n:
        magic_square[i][j] = num
        num += 1
        new_i, new_j = (i-1) % n, (j+1) % n
        if magic_square[new_i][new_j]:
            i = (i + 1) % n
        else:
            i, j = new_i, new_j

    for row in magic_square:
        print(" ".join(f"{x:2}" for x in row))

generate_magic_square(5)
'''
•	Input check: If n is even, print an error. This method only works for odd n.
•	Initializes n x n grid with 0.
•	Uses (i, j) as current cell position.
•	Fills in numbers 1 to n² using the rules above.
•	Finally, prints the magic square neatly
'''