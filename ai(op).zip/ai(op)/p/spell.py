from spellchecker import Spellchecker

def spell_check(text):
    spell=Spellchecker()
    words =text.split()
    misspelled =spell.unknown(words)

    corrected ={}
    for word in misspelled:
        corrected[word]=spell.correction(word)
    return corrected

text=input("enter a sentence: ")
corrections= spell_check(text)
print("corrections: ",corrections)