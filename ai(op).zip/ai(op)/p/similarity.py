import spacy

nlp =spacy.load("en_core_web_md")

def similarity_score():
    s1= input("enter the 1st sentence: ")
    s2= input("enter the 2nd sentence: ")


    doc1=nlp(s1)
    doc2=nlp(s2)

    score = doc1.similarity(doc2)
    print(f"similarity score : {score:.2f}")

similarity_score()
