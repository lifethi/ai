import spacy 
import warnings
warnings.filterwarnings("ignore",  category=UserWarning)

nlp=spacy.laod("en_core_web_md")

def pos_tagging(text):
    doc=nlp(text)
    results=[]
    for token in doc:
        results.append((token.text, token.pos_,token.tag_,spacy.explain(token.tag_)))
    return results

text=input("enyter the sentence:")
tagged=pos_tagging(text)


print("Token".ljust(15),"pos".ljust(10),"tag".ljust(10),"description")
for token in tagged:
    print(f"{token[0].ljust[15]}{token[1].ljust[10]}{token[2].ljust(10)}{token[3]}")

