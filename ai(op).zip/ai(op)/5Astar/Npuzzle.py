import heapq
import copy

# Moves: Right, Down, Left, Up
moves = [(0, 1), (1, 0), (0, -1), (-1, 0)]

def manhattan(state, goal_state, n):
    dist = 0
    for i in range(n):
        for j in range(n):
            val = state[i][j]
            if val != 0:
                for x in range(n):
                    for y in range(n):
                        if goal_state[x][y] == val:
                            dist += abs(i - x) + abs(j - y)
    return dist

def get_neighbors(state, n):
    neighbors = []
    for i in range(n):
        for j in range(n):
            if state[i][j] == 0:
                x, y = i, j
                break
    for dx, dy in moves:
        nx, ny = x + dx, y + dy
        if 0 <= nx < n and 0 <= ny < n:
            new_state = copy.deepcopy(state)
            new_state[x][y], new_state[nx][ny] = new_state[nx][ny], new_state[x][y]
            neighbors.append(new_state)
    return neighbors

def print_state(state):
    for row in state:
        print(" ".join(map(str, row)))
    print()

def a_star_search(start, goal_state, n):
    visited = set()
    pq = []
    heapq.heappush(pq, (manhattan(start, goal_state, n), 0, start))  # (f, g, state)
    steps = 0

    while pq:
        f, g, state = heapq.heappop(pq)
        state_tuple = tuple(tuple(row) for row in state)

        if state_tuple in visited:
            continue
        visited.add(state_tuple)

        print(f"Step {steps}, Cost (f = g+h) = {f}")
        print_state(state)
        steps += 1

        if state == goal_state:
            print("Goal Reached!")
            return

        for neighbor in get_neighbors(state, n):
            neighbor_tuple = tuple(tuple(row) for row in neighbor)
            if neighbor_tuple not in visited:
                g_new = g + 1
                h_new = manhattan(neighbor, goal_state, n)
                heapq.heappush(pq, (g_new + h_new, g_new, neighbor))

    print("No solution found.")

def input_state(name, n):
    print(f"Enter the {name} state row by row (space-separated, use 0 for blank):")
    state = []
    used = set()
    for i in range(n):
        while True:
            try:
                row = list(map(int, input(f"Row {i+1}: ").split()))
                if len(row) != n or any(x < 0 or x >= n*n or x in used for x in row):
                    raise ValueError
                used.update(row)
                state.append(row)
                break
            except:
                print(f"Invalid input. Enter {n} distinct numbers from 0 to {n*n - 1}.")
    return state

# ----------- MAIN -----------
def main():
    n = int(input("Enter the value of N for N-Puzzle (e.g., 3 for 8-puzzle, 4 for 15-puzzle): "))
    goal_state = [[(i * n + j + 1) % (n * n) for j in range(n)] for i in range(n)]
    initial_state = input_state("initial", n)

    print("\nGoal State:")
    print_state(goal_state)

    a_star_search(initial_state, goal_state, n)

if __name__ == "__main__":
    main()
