
import heapq

def best_first_search_cities(graph, start, goal):
  pq = []
  heapq.heappush(pq, (0, start))
  visited = set()
  parent = {start: None}
  steps = [] # To store step-by-step traversal

  #pop city with lowest cost
  while pq:
    cost, current = heapq.heappop(pq)
    steps.append(f"Visiting: {current} (Cost: {cost})")

    #if reached goal go to parent 
    if current == goal:
      path = []
      while current:
        path.append(current)
        current = parent[current]
      return path[::-1], steps

    visited.add(current)
    
    for neighbor, dist in graph[current].items():
      if neighbor not in visited:
        heapq.heappush(pq, (dist, neighbor))
        parent[neighbor] = current

  return None, steps

# User Input
print("Enter number of cities:")
n = int(input())
graph = {}

for _ in range(n):
  city = input("Enter city name: ")
  graph[city] = {}

print("Enter roads (city1 city2 distance), type 'done' to stop:")
while True:
  data = input()
  if data.lower() == "done":
    break
  city1, city2, dist = data.split()
  dist = int(dist)
  graph[city1][city2] = dist
  graph[city2][city1] = dist # Assuming bidirectional roads

print("Enter start city:")
start = input()
print("Enter goal city:")
goal = input()

path, steps = best_first_search_cities(graph, start, goal)

# Step-by-Step Output
print("\nStep-by-step traversal:")
for step in steps:
  print(step)

# Final Path Output
if path:
  print("\nShortest Path Found:", " → ".join(path))
else:
  print("\nNo path found!")


#input:
#Enter number of cities:
#4
#Enter city name: A
#Enter city name: B
#Enter city name: C
#Enter city name: D
#Enter roads (city1 city2 distance), type 'done' to stop:
#A B 1
#A C 4
#B D 2
#C D 1
#done
#Enter start city:
#A 
#Enter goal city:
#D

#m:
from collections import deque

def bfs(graph, start, goal):
    visited = set()
    queue = deque([(start, [start])])  # (current city, path taken)

    while queue:
        city, path = queue.popleft()
        if city == goal:
            return path

        if city not in visited:
            visited.add(city)
            for neighbor in graph[city]:
                if neighbor not in visited:
                    queue.append((neighbor, path + [neighbor]))
    return None

def main():
    graph = {}
    n = int(input("Enter the number of cities: "))

    print("Enter the names of the cities:")
    cities = [input(f"City {i+1}: ").strip() for i in range(n)]

    # Initialize adjacency list
    for city in cities:
        graph[city] = []

    m = int(input("Enter number of connections (edges): "))
    print("Enter each connection (e.g., CityA CityB):")
    for _ in range(m):
        u, v = input().split()
        graph[u].append(v)
        graph[v].append(u)  # Assuming undirected connections

    start = input("Enter the start city: ").strip()
    goal = input("Enter the goal city: ").strip()

    if start not in graph or goal not in graph:
        print("Start or goal city not in the city list.")
        return

    path = bfs(graph, start, goal)
    if path:
        print("Path found using BFS:")
        print(" -> ".join(path))
    else:
        print("No path found.")

if __name__ == "__main__":
    main()
