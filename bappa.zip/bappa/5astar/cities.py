import heapq

def a_star_search(graph, start, goal, heuristic):
    open_list = []
    heapq.heappush(open_list, (0 + heuristic[start], 0, start, [start]))
    visited = set()

    print("\nStep-by-step A* search:")
    print(f"{'Current':<10}{'g(n)':<10}{'h(n)':<10}{'f(n)':<10}{'Path'}")

    while open_list:
        est_total_cost, cost_so_far, current, path = heapq.heappop(open_list)

        if current in visited:
            continue
        visited.add(current)

        g = cost_so_far
        h = heuristic[current]
        f = g + h
        print(f"{current:<10}{g:<10}{h:<10}{f:<10}{' -> '.join(path)}")

        if current == goal:
            print("\nReached goal.")
            return path, cost_so_far

        for neighbor, distance in graph[current].items():
            if neighbor not in visited:
                total_cost = cost_so_far + distance
                est_cost = total_cost + heuristic[neighbor]
                heapq.heappush(open_list, (est_cost, total_cost, neighbor, path + [neighbor]))

    return None, float('inf')


def take_input():
    graph = {}
    heuristic = {}

    n = int(input("Enter number of cities: "))
    print("Enter city names:")
    cities = [input(f"City {i + 1}: ") for i in range(n)]

    print("\nEnter distances between cities (format: City1 City2 Distance), type 'done' to stop:")
    while True:
        entry = input()
        if entry.lower() == 'done':
            break
        city1, city2, dist = entry.split()
        dist = int(dist)
        if city1 not in graph:
            graph[city1] = {}
        if city2 not in graph:
            graph[city2] = {}
        graph[city1][city2] = dist
        graph[city2][city1] = dist  # assuming undirected graph

    print("\nEnter heuristic values (Estimated distance to goal):")
    for city in cities:
        heuristic[city] = int(input(f"Heuristic for {city}: "))

    start = input("\nEnter source city: ")
    goal = input("Enter destination city: ")

    return graph, heuristic, start, goal


if _name_ == "_main_":
    graph, heuristic, start, goal = take_input()
    path, cost = a_star_search(graph, start, goal, heuristic)
    if path:
        print("\nShortest Path:", ' -> '.join(path))
        print("Total Cost:", cost)
    else:
        print("No path found between the given cities.")





#input:


#Enter number of cities: 4
#Enter city names:
#City 1: A
#City 2: B
#City 3: C
#City 4: D

#Enter distances between cities (format: City1 City2 Distance), type 'done' to stop:
#A B 1
#B C 3
#A D 4
#C D 2
#done

#Enter heuristic values (Estimated distance to goal):
#Heuristic for A: 4
#Heuristic for B: 2
#Heuristic for C: 1
#Heuristic for D: 0

#Enter source city: A
#Enter destination city: D

#Step-by-step A* search:
#Current   g(n)      h(n)      f(n)      Path
#A         0         4         4         A
#B         1         2         3         A -> B
#D         4         0         4         A -> D

#Reached goal.

#Shortest Path: A -> D
#Total Cost: 4



