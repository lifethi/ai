
from copy import deepcopy
from queue import PriorityQueue
import math


class Node:
    def __init__(self, state, parent, move, depth, cost):
        self.state = state
        self.parent = parent
        self.move = move
        self.depth = depth
        self.cost = cost

    def __lt_import logging

logging.basicConfig(level=logging.INFO, format='%(asctime)s - %(levelname)s - %(message)s')

class Node:
    def __init__(self, state, parent, move, depth, cost):
        self.state = state
        self.parent = parent
        self.move = move
        self.depth = depth
        self.cost = cost

    def __lt__(self, other):
        return self.cost < other.cost


class NPuzzle:
    def __init__(self, start, goal):
        self.start = start
        self.goal = goal
        self.size = len(start)
        self.moves = []
        self.directions = {
            'UP': (-1, 0),
            'DOWN': (1, 0),
            'LEFT': (0, -1),
            'RIGHT': (0, 1)
        }

    def find_blank(self, state):
        for i in range(self.size):
            for j in range(self.size):
                if state[i][j] == 0:
                    return i, j

    def move_tile(self, state, direction):
        x, y = self.find_blank(state)
        dx, dy = self.directions[direction]
        nx, ny = x + dx, y + dy
        if 0 <= nx < self.size and 0 <= ny < self.size:
            new_state = deepcopy(state)
            new_state[x][y], new_state[nx][ny] = new_state[nx][ny], new_state[x][y]
            return new_state
        return None

    def state_to_tuple(self, state):
        return tuple(tuple(row) for row in state)

    def manhattan(self, state):
        total = 0
        for i in range(self.size):
            for j in range(self.size):
                val = state[i][j]
                if val != 0:
                    goal_x = (val - 1) // self.size
                    goal_y = (val - 1) % self.size
                    total += abs(goal_x - i) + abs(goal_y - j)
        return total

    def heuristic(self, node):
        return node.depth + self.manhattan(node.state)

    def expand_node(self, node, visited):
        children = []
        for move in self.directions.keys():
            new_state = self.move_tile(node.state, move)
            if new_state and self.state_to_tuple(new_state) not in visited:
                child = Node(new_state, node, move, node.depth + 1, 0)
                children.append(child)
        return children

    def solve(self):
        logging.info("Starting puzzle solving")
        root = Node(self.start, None, None, 0, 0)
        root.cost = self.heuristic(root)
        frontier = PriorityQueue()
        frontier.put(root)
        visited = set()
        visited.add(self.state_to_tuple(self.start))

        while not frontier.empty():
            current = frontier.get()
            logging.info(f"Current node depth: {current.depth}, cost: {current.cost}")
            if current.state == self.goal:
                logging.info("Puzzle solved")
                path = []
                while current.parent:
                    path.append(current.move)
                    current = current.parent
                path.reverse()
                self.moves = path
                return path

            for child in self.expand_node(current, visited):
                child.cost = self.heuristic(child)
                frontier.put(child)
                visited.add(self.state_to_tuple(child.state))

        logging.info("No solution found")
        return None


def main():
    print("N-PUZZLE SOLVER USING A* SEARCH\n")
    size = int(input("Enter puzzle size (e.g., 3 for 3x3): "))

    print("Enter the start state row by row, use 0 for blank:")
    start = [list(map(int, input().split())) for _ in range(size)]

    print("Enter the goal state row by row:")
    goal = [list(map(int, input().split())) for _ in range(size)]

    puzzle = NPuzzle(start, goal)
    solution = puzzle.solve()

    if solution:
        print("\nPuzzle solved in", len(solution), "moves:")
        for i, move in enumerate(solution):
            print(f"{i+1}. {move}")
    else:
        print("No solution found.")


if __name__ == "__main__":
    main()_(self, other):
        return self.cost < other.cost


class NPuzzle:
    def __init__(self, start, goal):
        self.start = start
        self.goal = goal
        self.size = len(start)
        self.moves = []
        self.directions = {
            'UP': (-1, 0),
            'DOWN': (1, 0),
            'LEFT': (0, -1),
            'RIGHT': (0, 1)
        }

    def find_blank(self, state):
        for i in range(self.size):
            for j in range(self.size):
                if state[i][j] == 0:
                    return i, j

    def move_tile(self, state, direction):
        x, y = self.find_blank(state)
        dx, dy = self.directions[direction]
        nx, ny = x + dx, y + dy
        if 0 <= nx < self.size and 0 <= ny < self.size:
            new_state = deepcopy(state)
            new_state[x][y], new_state[nx][ny] = new_state[nx][ny], new_state[x][y]
            return new_state
        return None

    def state_to_tuple(self, state):
        return tuple(tuple(row) for row in state)

    def manhattan(self, state):
        total = 0
        for i in range(self.size):
            for j in range(self.size):
                val = state[i][j]
                if val != 0:
                    goal_x = (val - 1) // self.size
                    goal_y = (val - 1) % self.size
                    total += abs(goal_x - i) + abs(goal_y - j)
        return total

    def heuristic(self, node):
        return node.depth + self.manhattan(node.state)

    def expand_node(self, node, visited):
        children = []
        for move in self.directions.keys():
            new_state = self.move_tile(node.state, move)
            if new_state and self.state_to_tuple(new_state) not in visited:
                child = Node(new_state, node, move, node.depth + 1, 0)
                children.append(child)
        return children

    def solve(self):
        root = Node(self.start, None, None, 0, 0)
        root.cost = self.heuristic(root)
        frontier = PriorityQueue()
        frontier.put(root)
        visited = set()
        visited.add(self.state_to_tuple(self.start))

        while not frontier.empty():
            current = frontier.get()
            if current.state == self.goal:
                path = []
                while current.parent:
                    path.append(current.move)
                    current = current.parent
                path.reverse()
                self.moves = path
                return path

            for child in self.expand_node(current, visited):
                child.cost = self.heuristic(child)
                frontier.put(child)
                visited.add(self.state_to_tuple(child.state))

        return None


def main():
    print("N-PUZZLE SOLVER USING A* SEARCH\n")
    size = int(input("Enter puzzle size (e.g., 3 for 3x3): "))

    print("Enter the start state row by row, use 0 for blank:")
    start = [list(map(int, input().split())) for _ in range(size)]

    print("Enter the goal state row by row:")
    goal = [list(map(int, input().split())) for _ in range(size)]

    puzzle = NPuzzle(start, goal)
    solution = puzzle.solve()

    if solution:
        print("\nPuzzle solved in", len(solution), "moves:")
        for i, move in enumerate(solution):
            print(f"{i+1}. {move}")
    else:
        print("No solution found.")

if __name__ == "__main__":
    main()


input:
Enter the start state row by row, use 0 for blank:
1 2 3 
4 0 6
7 5 8 
Enter the goal state row by row:
1 2 3 
4 5 6 
7 8 0

Puzzle solved in 2 moves:
1. DOWN
2. RIGHT


m:

import heapq
import copy

# Moves: Right, Down, Left, Up
moves = [(0, 1), (1, 0), (0, -1), (-1, 0)]

def manhattan(state, goal_state, n):
    dist = 0
    for i in range(n):
        for j in range(n):
            val = state[i][j]
            if val != 0:
                for x in range(n):
                    for y in range(n):
                        if goal_state[x][y] == val:
                            dist += abs(i - x) + abs(j - y)
    return dist

def get_neighbors(state, n):
    neighbors = []
    for i in range(n):
        for j in range(n):
            if state[i][j] == 0:
                x, y = i, j
                break
    for dx, dy in moves:
        nx, ny = x + dx, y + dy
        if 0 <= nx < n and 0 <= ny < n:
            new_state = copy.deepcopy(state)
            new_state[x][y], new_state[nx][ny] = new_state[nx][ny], new_state[x][y]
            neighbors.append(new_state)
    return neighbors

def print_state(state):
    for row in state:
        print(" ".join(map(str, row)))
    print()

def a_star_search(start, goal_state, n):
    visited = set()
    pq = []
    heapq.heappush(pq, (manhattan(start, goal_state, n), 0, start))  # (f, g, state)
    steps = 0

    while pq:
        f, g, state = heapq.heappop(pq)
        state_tuple = tuple(tuple(row) for row in state)

        if state_tuple in visited:
            continue
        visited.add(state_tuple)

        print(f"Step {steps}, Cost (f = g+h) = {f}")
        print_state(state)
        steps += 1

        if state == goal_state:
            print("Goal Reached!")
            return

        for neighbor in get_neighbors(state, n):
            neighbor_tuple = tuple(tuple(row) for row in neighbor)
            if neighbor_tuple not in visited:
                g_new = g + 1
                h_new = manhattan(neighbor, goal_state, n)
                heapq.heappush(pq, (g_new + h_new, g_new, neighbor))

    print("No solution found.")

def input_state(name, n):
    print(f"Enter the {name} state row by row (space-separated, use 0 for blank):")
    state = []
    used = set()
    for i in range(n):
        while True:
            try:
                row = list(map(int, input(f"Row {i+1}: ").split()))
                if len(row) != n or any(x < 0 or x >= n*n or x in used for x in row):
                    raise ValueError
                used.update(row)
                state.append(row)
                break
            except:
                print(f"Invalid input. Enter {n} distinct numbers from 0 to {n*n - 1}.")
    return state

# ----------- MAIN -----------
def main():
    n = int(input("Enter the value of N for N-Puzzle (e.g., 3 for 8-puzzle, 4 for 15-puzzle): "))
    goal_state = [[(i * n + j + 1) % (n * n) for j in range(n)] for i in range(n)]
    initial_state = input_state("initial", n)

    print("\nGoal State:")
    print_state(goal_state)

    a_star_search(initial_state, goal_state, n)

if __name__ == "__main__":
    main()







