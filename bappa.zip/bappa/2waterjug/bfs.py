from collections import deque

def water_jug_bfs(capacity1, capacity2, target):
    visited = set()
    queue = deque([(0, 0)])
    parent = {}

    while queue:
        jug1, jug2 = queue.popleft()

        if jug1 == target or jug2 == target:
            path = []
            while (jug1, jug2) in parent:
                path.append((jug1, jug2))
                jug1, jug2 = parent[(jug1, jug2)]
            path.append((0, 0))
            return path[::-1]

        if (jug1, jug2) in visited:
            continue

        visited.add((jug1, jug2))

        next_states = [
            (capacity1, jug2),  
            (jug1, capacity2),  
            (0, jug2),          
            (jug1, 0),          
            (max(0, jug1 - (capacity2 - jug2)), min(capacity2, jug1 + jug2)), 
            (min(capacity1, jug1 + jug2), max(0, jug2 - (capacity1 - jug1)))  
        ]

        for state in next_states:
            if state not in visited:
                queue.append(state)
                parent[state] = (jug1, jug2)

    return None

# Take user input
try:
    capacity1 = int(input("Enter capacity of Jug 1: "))
    capacity2 = int(input("Enter capacity of Jug 2: "))
    target = int(input("Enter target amount: "))
except ValueError:
    print("Invalid input. Please enter integers only.")
    exit()

# Solve
solution = water_jug_bfs(capacity1, capacity2, target)

# Display
if solution:
    print("\nSteps to reach the target:")
    for step in solution:
        print(f"Jug1: {step[0]}, Jug2: {step[1]}")
else:
    print("No solution found.")


