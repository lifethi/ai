#1c magicsquare 

#P:
def print_board(board):
    """Prints the N-Queens board."""
    for row in board:
        print(" ".join("Q" if cell else "." for cell in row))
    print("\n")


def is_safe(board, row, col, n):
    """Checks if placing a queen at (row, col) is safe."""
    # Check the column
    for i in range(row):
        if board[i][col]:
            return False

    # Check the upper-left diagonal
    for i, j in zip(range(row, -1, -1), range(col, -1, -1)):
        if board[i][j]:
            return False

    # Check the upper-right diagonal
    for i, j in zip(range(row, -1, -1), range(col, n)):
        if board[i][j]:
            return False

    return True


def solve_nqueens(board, row, n):
    """Solves the N-Queens problem using backtracking."""
    if row == n:
        print_board(board)
        return True

    success = False
    for col in range(n):
        if is_safe(board, row, col, n):
            board[row][col] = 1  # Place the queen
            success = solve_nqueens(board, row + 1, n) or success
            board[row][col] = 0  # Backtrack

    return success


def n_queens(n):
    """Main function to initialize the board and solve the problem."""
    board = [[0 for _ in range(n)] for _ in range(n)]
    if not solve_nqueens(board, 0, n):
        print("No solution exists.")


# Example usage:
if __name__ == "__main__":
    N = int(input("Enter the value of N: "))
    n_queens(N)



#a:
def calculate_size(magic_sum):
    """Estimate the size of the magic square (odd n)."""
    n = 3  # Start with the smallest odd size
    while True:
        original_magic_sum = n * (n**2 + 1) // 2
        if original_magic_sum > magic_sum:
            break
        n += 2
    return n - 2 if n > 3 else 3  # Adjust to the nearest valid odd size


def create_magic_square(n):
    """Generate magic square using the Siamese method."""
    magic_square = [[0] * n for _ in range(n)]
    i, j = 0, n // 2

    for num in range(1, n * n + 1):
        magic_square[i][j] = num
        new_i, new_j = (i - 1) % n, (j + 1) % n
        if magic_square[new_i][new_j]:
            i = (i + 1) % n
        else:
            i, j = new_i, new_j

    return magic_square


def scale_magic_square(square, target_sum):
    """Scale the magic square to match the desired magic sum."""
    n = len(square)
    original_sum = n * (n**2 + 1) // 2
    scale_factor = target_sum / original_sum
    return [[round(cell * scale_factor, 2) for cell in row] for row in square]


def display_magic_square(square):
    """Print the magic square in terminal."""
    print("\nGenerated Magic Square:")
    for row in square:
        print("  ".join(f"{cell:6}" for cell in row))


def main():
    try:
        magic_sum = int(input("Enter a Magic Sum: "))
        if magic_sum <= 0:
            raise ValueError("Please enter a positive number.")

        n = calculate_size(magic_sum)
        magic_square = create_magic_square(n)
        scaled_magic_square = scale_magic_square(magic_square, magic_sum)

        display_magic_square(scaled_magic_square)

    except ValueError as e:
        print(f"Input Error: {e}")


if _name_ == "_main_":
    main()

