


#1b) nqueen:

#p:

def print_board(board):
    """Prints the N-Queens board."""
    for row in board:
        print(" ".join("Q" if cell else "." for cell in row))
    print("\n")


def is_safe(board, row, col, n):
    """Checks if placing a queen at (row, col) is safe."""
    # Check the column
    for i in range(row):
        if board[i][col]:
            return False

    # Check the upper-left diagonal
    for i, j in zip(range(row, -1, -1), range(col, -1, -1)):
        if board[i][j]:
            return False

    # Check the upper-right diagonal
    for i, j in zip(range(row, -1, -1), range(col, n)):
        if board[i][j]:
            return False

    return True


def solve_nqueens(board, row, n):
    """Solves the N-Queens problem using backtracking."""
    if row == n:
        print_board(board)
        return True

    success = False
    for col in range(n):
        if is_safe(board, row, col, n):
            board[row][col] = 1  # Place the queen
            success = solve_nqueens(board, row + 1, n) or success
            board[row][col] = 0  # Backtrack

    return success


def n_queens(n):
    """Main function to initialize the board and solve the problem."""
    board = [[0 for _ in range(n)] for _ in range(n)]
    if not solve_nqueens(board, 0, n):
        print("No solution exists.")


# Example usage:
if __name__ == "__main__":
    N = int(input("Enter the value of N: "))
    n_queens(N)


#a:

def print_solution(board, N):
    for i in range(N):
        for j in range(N):
            if board[i][j] == 1:
                print(" Q ", end="")
            else:
                print(" . ", end="")
        print()


def solve_nq_util(board, col, N, ld, rd, cl):
    if col >= N:
        return True

    for i in range(N):
        if ld[i - col + N - 1] == 0 and rd[i + col] == 0 and cl[i] == 0:
            board[i][col] = 1
            ld[i - col + N - 1] = rd[i + col] = cl[i] = 1

            if solve_nq_util(board, col + 1, N, ld, rd, cl):
                return True

            board[i][col] = 0
            ld[i - col + N - 1] = rd[i + col] = cl[i] = 0

    return False


def main():
    try:
        N = int(input("Enter the size of the board (N): "))
    except ValueError:
        print("Invalid input. Please enter a positive integer.")
        return

    if N < 1:
        print("Invalid board size. N must be greater than 0.")
        return

    board = [[0 for _ in range(N)] for _ in range(N)]
    ld = [0] * (2 * N)
    rd = [0] * (2 * N)
    cl = [0] * N

    if solve_nq_util(board, 0, N, ld, rd, cl):
        print_solution(board, N)
    else:
        print("Solution does not exist")


if _name_ == "_main_":
    main()