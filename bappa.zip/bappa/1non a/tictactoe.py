
# p:
def print_board(board):
    """Prints the current state of the board."""
    print("  0   1   2")
    for i, row in enumerate(board):
        print(f"{i} {' | '.join(row)}")
        if i < 2:
            print("  ---+---+---")


def check_winner(board, player):
    """Checks if the given player has won."""
   
    for i in range(3):
        if all([cell == player for cell in board[i]]):  
            return True
        if all([board[j][i] == player for j in range(3)]):  
            return True
    if all([board[i][i] == player for i in range(3)]):  
        return True
    if all([board[i][2 - i] == player for i in range(3)]):  
        return True
    return False


def is_full(board):
    """Checks if the board is full."""
    return all([cell != ' ' for row in board for cell in row])


def main():
    """Main function to play Tic Tac Toe."""
    board = [[' ' for _ in range(3)] for _ in range(3)]
    current_player = 'X'

    print("Welcome to Tic Tac Toe!")
    print_board(board)

    while True:
        try:
            print(f"Player {current_player}, it's your turn.")
            row = int(input("Enter the row (0-2): "))
            col = int(input("Enter the column (0-2): "))

            if board[row][col] == ' ':
                board[row][col] = current_player
                print_board(board)

                if check_winner(board, current_player):
                    print(f"Player {current_player} wins!")
                    break

                if is_full(board):
                    print("It's a draw!")
                    break

                
                current_player = 'O' if current_player == 'X' else 'X'
            else:
                print("Cell already taken. Choose a different cell.")

        except (ValueError, IndexError):
            print("Invalid input. Please enter a row and column between 0 and 2.")


if __name__ == "__main__":
    main()  



# a:
import os

# Color codes for terminal output
BLUE = '\033[94m'
RED = '\033[91m'
RESET = '\033[0m'

board = [" " for _ in range(9)]
turn = "X"

def colorize(value):
    if value == "X":
        return BLUE + value + RESET
    elif value == "O":
        return RED + value + RESET
    return value

def print_board():
    print("|---|---|---|")
    print(f"| {colorize(board[0])} | {colorize(board[1])} | {colorize(board[2])} |")
    print("|-----------|")
    print(f"| {colorize(board[3])} | {colorize(board[4])} | {colorize(board[5])} |")
    print("|-----------|")
    print(f"| {colorize(board[6])} | {colorize(board[7])} | {colorize(board[8])} |")
    print("|---|---|---|")

def check_winner():
    lines = [
        board[0] + board[1] + board[2],
        board[3] + board[4] + board[5],
        board[6] + board[7] + board[8],
        board[0] + board[3] + board[6],
        board[1] + board[4] + board[7],
        board[2] + board[5] + board[8],
        board[0] + board[4] + board[8],
        board[2] + board[4] + board[6],
    ]

    for line in lines:
        if line == "XXX":
            return "X"
        elif line == "OOO":
            return "O"

    if " " not in board:
        return "draw"
    
    return None

def main():
    global turn
    print("Welcome to 3x3 Tic Tac Toe.")
    print_board()
    print("X will play first. Enter a slot number to place X in:")

    winner = None
    while winner is None:
        try:
            num_input = int(input(f"{turn}'s turn; enter a slot number (1-9): "))
            if not (1 <= num_input <= 9):
                print("Invalid input; re-enter slot number:")
                continue
        except ValueError:
            print("Invalid input; please enter a number:")
            continue

        if board[num_input - 1] == " ":
            board[num_input - 1] = turn
            turn = "O" if turn == "X" else "X"
            print_board()
            winner = check_winner()
        else:
            print("Slot already taken; re-enter slot number:")

    if winner == "draw":
        print("It's a draw! Thanks for playing.")
    else:
        print(f"Congratulations! {winner}'s have won! Thanks for playing.")

if _name_ == "_main_":
    main()


