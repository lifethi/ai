p:
import nltk
import os


# Suppress NLTK download messages
nltk.data.path.append(os.path.join(os.getcwd(), 'nltk_data'))


# Check if the necessary resources are already downloaded
try:
    nltk.data.find('tokenizers/punkt')
    nltk.data.find('taggers/averaged_perceptron_tagger')
except LookupError:
    print("Required NLTK resources are not found.")


# Full POS Tag Meanings
pos_tag_meanings = {
    'NN': 'Noun, singular',
    'NNS': 'Noun, plural',
    'NNP': 'Proper noun, singular',
    'NNPS': 'Proper noun, plural',
    'VB': 'Verb, base form',
    'VBD': 'Verb, past tense',
    'VBG': 'Verb, gerund/present participle',
    'VBN': 'Verb, past participle',
    'VBP': 'Verb, non-3rd person singular present',
    'VBZ': 'Verb, 3rd person singular present',
    'JJ': 'Adjective',
    'RB': 'Adverb',
    'IN': 'Preposition',
    'DT': 'Determiner',
    'PRP': 'Personal pronoun',
     '.': 'Punctuation',
    'CC': 'Coordinating conjunction'
    
}


def pos_tagging():
    sentence = input("Enter a sentence for POS tagging: ")
    tokens = nltk.word_tokenize(sentence)
    tags = nltk.pos_tag(tokens)
   
    print("\nPart of Speech Tags and their Meaning:")
    for word, tag in tags:
        meaning = pos_tag_meanings.get(tag, "Unknown tag")
        print(f"{word} -> {tag}: {meaning}")


# Call POS tagging function
pos_tagging()



m:
import spacy

# Load the spaCy English model
nlp = spacy.load("en_core_web_sm")

def pos_tagging(text):
    doc = nlp(text)
    results = []
    for token in doc:
        results.append((token.text, token.pos_, token.tag_, spacy.explain(token.tag_)))
    return results

# Example usage
text = "The quick brown fox jumps over the lazy dog"
tagged = pos_tagging(text)

print("Token".ljust(15), "POS".ljust(10), "Tag".ljust(10), "Description")
print("-" * 50)
for token in tagged:
    print(f"{token[0].ljust(15)}{token[1].ljust(10)}{token[2].ljust(10)}{token[3]}")


or userinput m:

import spacy
import warnings
warnings.filterwarnings("ignore", category=UserWarning)

# Load the spaCy English model
nlp = spacy.load("en_core_web_sm")

def pos_tagging(text):
    doc = nlp(text)
    results = []
    for token in doc:
        results.append((token.text, token.pos_, token.tag_, spacy.explain(token.tag_)))
    return results

# Example usage
text = input("enter the sentence: ")
tagged = pos_tagging(text)

print("Token".ljust(15), "POS".ljust(10), "Tag".ljust(10), "Description")
print("-" * 50)
for token in tagged:
    print(f"{token[0].ljust(15)}{token[1].ljust(10)}{token[2].ljust(10)}{token[3]}")



pip install spacy
python -m spacy download en_core_web_md


a:

from textblob import TextBlob

def textblob_pos_tagger(sentence):
 
    
    # Common POS tag explanations (simplified Penn Treebank tags)
    TAG_MEANINGS = {
        'DT': 'Determiner', 'JJ': 'Adjective', 'NN': 'Noun', 
        'VBZ': 'Verb (3rd person singular)', 'IN': 'Preposition',
        '.': 'Punctuation mark'
    }
    
    try:
        blob = TextBlob(sentence)
        tags = blob.tags
        
        # Format output with explanations
        formatted = []
        for word, tag in tags:
            explanation = TAG_MEANINGS.get(tag, tag)
            formatted.append(f"{word:10} {tag:5} ({explanation})")
        
        print("\nPOS Tagging Results:")
        print("-" * 40)
        print("\n".join(formatted))
        print("-" * 40)
        
        return tags
        
    except Exception as e:
        print(f"Error: {e}")
        return []

if _name_ == "_main_":
    while True:
        sentence = input("\nEnter a sentence (or 'q' to quit): ")
        if sentence.lower() == 'q':
            break
        textblob_pos_tagger(sentence)


cmd: pip install textblob
sentence: The quick brown fox jumps over the lazy dog


