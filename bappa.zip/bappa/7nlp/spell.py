
import language_tool_python


tool = language_tool_python.LanguageTool('en-US')
sentence = input("Enter a sentence with spelling errors: ")
matches = tool.check(sentence)
corrected = language_tool_python.utils.correct(sentence, matches)
print("\nCorrected Sentence:")
print(corrected)




Or:


import re
from collections import Counter
from string import ascii_lowercase


# Sample minimal vocabulary to demonstrate (replace with full corpus if needed)
sample_corpus = """
i am learning natural language processing python java hello world
this is a simple example spell checker program
"""


# Function to extract words from text
def words(text):
    return re.findall(r"[a-z]+", text.lower())


# Function to generate alternate spellings for a word
def alternate_words(word):
    lst = []


    for i in ascii_lowercase:
        for j in range(len(word) + 1):
            lst.append(word[:j] + i + word[j:])


    for i in range(1, len(word)):
        lst.append(word[:i-1] + word[i] + word[i-1] + word[i+1:])


    for i in range(len(word)):
        lst.append(word[:i] + word[i+1:])


    for i in ascii_lowercase:
        for j in range(len(word)):
            lst.append(word[:j] + i + word[j+1:])


    return lst


# Frequency of word in corpus
def valueOf(word):
    return Vocabulary[word]


# Spell checker
def spelled_word(word):
    suggestions = set(alternate_words(word)).intersection(set(Vocabulary))
    if suggestions:
        maxScoreWord = max(suggestions, key=valueOf)
        return sorted([i for i in suggestions if Vocabulary[i] == Vocabulary[maxScoreWord]])[0]
    return word


# Build vocabulary
Vocabulary = Counter(words(sample_corpus))


# Take full sentence input
sentence = input("Enter a sentence with spelling errors: ").strip()


corrected_words = []
for word in sentence.split():
    cleaned = re.sub(r'[^a-zA-Z]', '', word)
    if cleaned.lower() in Vocabulary:
        corrected_words.append(word)
    else:
        corrected = spelled_word(cleaned.lower())
        corrected_words.append(corrected)


# Output corrected sentence
print("\nCorrected Sentence:")
print(" ".join(corrected_words))





or
More correct :

#pip install pyspellchecker


from spellchecker import SpellChecker


def spell_check(text):
    # Initialize the spell checker
    spell = SpellChecker()
   
    # Split the input text into words
    words = text.split()
   
    # Find words that are misspelled
    misspelled = spell.unknown(words)
   
    # Correct the misspelled words
    corrected = {}
    for word in misspelled:
        corrected[word] = spell.correction(word)
   
    return corrected


# Example usage
text = "I havv a grekt day"
corrections = spell_check(text)
print("Corrections:", corrections)


cmd:
pip install pyspellchecker

