p:
from itertools import permutations
import re


def extract_unique_letters(expression):
    return sorted(set(re.sub(r'[^A-Z]', '', expression)))


def expression_to_number(expr, mapping):
    return int(''.join(str(mapping[c]) for c in expr))


def is_valid_mapping(mapping, terms, result):
    # No term can start with a zero
    for word in terms + [result]:
        if mapping[word[0]] == 0:
            return False
    total = sum(expression_to_number(term, mapping) for term in terms)
    return total == expression_to_number(result, mapping)


def solve_cryptarithmetic():
    expr = input("Enter expression (e.g., SEND + MORE = MONEY): ").replace(" ", "").upper()
   
    # Parse expression
    try:
        left, right = expr.split('=')
        terms = left.split('+')
        result = right
    except ValueError:
        print("Invalid format. Use format: SEND + MORE = MONEY")
        return


    letters = extract_unique_letters(expr)
    if len(letters) > 10:
        print("Too many unique letters (max 10 allowed).")
        return


    for perm in permutations(range(10), len(letters)):
        mapping = dict(zip(letters, perm))
        if is_valid_mapping(mapping, terms, result):
            print("\nSolution found!")
            for k in sorted(mapping.keys()):
                print(f"{k} = {mapping[k]}")
            term_values = [expression_to_number(term, mapping) for term in terms]
            result_value = expression_to_number(result, mapping)
            print(f"\n{' + '.join(map(str, term_values))} = {result_value}")
            return


    print("No solution found.")


solve_cryptarithmetic()




input: to + go = out



a:

from itertools import permutations

def solve_cryptarithmetic(puzzle, max_solutions=None):
  """Solves cryptarithmetic puzzles and returns all solutions"""
  try:
    # Parse and validate input
    parts = [p for p in puzzle.upper().split() if p != '=']
    if len(parts) < 3:
      raise ValueError("Invalid puzzle format")
    
    # Extract words and operator
    words = []
    operator = None
    for part in parts:
      if part in ['+', '-', '*', '/']:
        operator = part
      elif part.isalpha():
        words.append(part)
    
    if len(words) != 3 or not operator:
      raise ValueError("Need two operands and a result")
    
    left, right, result = words
    unique_chars = sorted(set(left + right + result))
    first_letters = {word[0] for word in words}
    
    if len(unique_chars) > 10:
      return []
    
    solutions = []
    
    for perm in permutations(range(10), len(unique_chars)):
      mapping = dict(zip(unique_chars, perm))
      
      # Skip solutions with leading zeros
      if any(mapping[char] == 0 for char in first_letters):
        continue
      
      # Convert words to numbers
      try:
        left_num = int(''.join(str(mapping[c]) for c in left))
        right_num = int(''.join(str(mapping[c]) for c in right))
        result_num = int(''.join(str(mapping[c]) for c in result))
      except KeyError:
        continue
      
      # Check equation
      if operator == '+' and left_num + right_num == result_num:
        solutions.append(mapping)
      elif operator == '-' and left_num - right_num == result_num:
        solutions.append(mapping)
      elif operator == '*' and left_num * right_num == result_num:
        solutions.append(mapping)
      elif operator == '/' and left_num / right_num == result_num:
        solutions.append(mapping)
      
      if max_solutions and len(solutions) >= max_solutions:
        break
    
    return solutions
  
  except Exception as e:
    print(f"Error: {e}")
    return []

def print_solutions(puzzle, solutions):
  """Prints all solutions with formatting"""
  if not solutions:
    print("\nNo solutions found for:", puzzle)
    return
  
  print(f"\nFound {len(solutions)} solution(s) for: {puzzle}")
  for i, solution in enumerate(solutions, 1):
    sub_eq = puzzle.upper()
    for char, digit in solution.items():
      sub_eq = sub_eq.replace(char, str(digit))
    
    print(f"\nSolution {i}:")
    print(sub_eq)
    print("Letter assignments:")
    for char, digit in sorted(solution.items()):
      print(f"{char}: {digit}")

def get_user_input():
  """Gets and validates user input"""
  print("\n" + "="*50)
  print("CRYPTARITHMETIC SOLVER (MULTIPLE SOLUTIONS)".center(50))
  print("="*50)
  print("\nEnter puzzles like 'WORD + WORD = WORD'")
  print("Try: 'TAKE + A = CAKE' for multiple solutions")
  print("Type 'quit' to exit\n")
  
  while True:
    puzzle = input("Enter puzzle> ").strip()
    if puzzle.lower() in ('quit', 'exit', 'q'):
      return None
    if any(op in puzzle for op in ['+', '-', '*', '/', '=']):
      return puzzle
    print("Must contain an operator (+-*/) and equals sign (=)")

def main():
  while True:
    puzzle = get_user_input()
    if not puzzle:
      print("\nGoodbye!")
      break
    
    print(f"\nSolving: {puzzle}")
    solutions = solve_cryptarithmetic(puzzle)
    print_solutions(puzzle, solutions)
    print("\n" + "="*50)

if _name_ == "_main_":
  main()






