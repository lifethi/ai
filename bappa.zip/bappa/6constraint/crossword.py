b. Crossword puzzle 
def solve_crossword(grid, words):
    def is_valid(word, row, col, direction):
        if direction == 'across':
            if col + len(word) > len(grid[0]):
                return False
            for i, letter in enumerate(word):
                if grid[row][col + i] not in ('_', letter):
                    return False
        elif direction == 'down':
            if row + len(word) > len(grid):
                return False
            for i, letter in enumerate(word):
                if grid[row + i][col] not in ('_', letter):
                    return False
        return True


    def place_word(word, row, col, direction):
        if direction == 'across':
            for i, letter in enumerate(word):
                grid[row][col + i] = letter
        elif direction == 'down':
            for i, letter in enumerate(word):
                grid[row + i][col] = letter


    def remove_word(word, row, col, direction):
        if direction == 'across':
            for i, _ in enumerate(word):
                grid[row][col + i] = '_'
        elif direction == 'down':
            for i, _ in enumerate(word):
                grid[row + i][col] = '_'


    def solve_util(words_to_place):
        if not words_to_place:
            return True


        word = words_to_place.pop()
        for row in range(len(grid)):
            for col in range(len(grid[0])):
                for direction in ('across', 'down'):
                    if is_valid(word, row, col, direction):
                        place_word(word, row, col, direction)
                        if solve_util(words_to_place):
                            return True
                        remove_word(word, row, col, direction)
        words_to_place.append(word)
        return False


    words_to_place = list(words)
    return solve_util(words_to_place)


def print_grid(grid):
    for row in grid:
        print(' '.join(row))


# Input
rows = int(input("Enter the number of rows in the crossword grid: "))
cols = int(input("Enter the number of columns in the crossword grid: "))
grid = [['_' for _ in range(cols)] for _ in range(rows)]


num_words = int(input("Enter the number of words: "))
words = []
for i in range(num_words):
    word = input(f"Enter word {i + 1}: ").upper()
    words.append(word)


# Solve the crossword puzzle
solution_found = solve_crossword(grid, words)


if solution_found:
    print("Solution found:")
    print_grid(grid)
else:
    print("No solution found.")




Enter the number of rows in the crossword grid: 5
Enter the number of columns in the crossword grid: 5
Enter the number of words: 3
Enter word 1: HELLO
Enter word 2: WORLD
Enter word 3: HOW





