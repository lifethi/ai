def get_user_input():
    n = int(input("Enter number of nodes: "))
    nodes = []
    adjacency = {}

    print("Enter node names (e.g. A, B, C):")
    for _ in range(n):
        node = input("Node: ").strip().upper()
        nodes.append(node)

    print("Enter adjacency list (space-separated neighbors):")
    for node in nodes:
        neighbors = input(f"Neighbors of {node}: ").strip().upper().split()
        adjacency[node] = neighbors

    print("Enter colors separated by commas (e.g. Red,Green,Blue):")
    colors = [color.strip().capitalize() for color in input().split(',')]

    return nodes, adjacency, colors

def is_safe(state, node, color, adjacency): 
    for neighbor in adjacency[node]: 
        if neighbor in state and state[neighbor] == color: 
            return False 
    return True 

def map_coloring(state, nodes, adjacency, colors): 
    if not nodes: 
        print("\nColoring Solution:")
        for node in sorted(state):
            print(f"{node} => {state[node]}")
        return True 

    node = nodes[0] 
    for color in colors: 
        if is_safe(state, node, color, adjacency): 
            state[node] = color 
            if map_coloring(state, nodes[1:], adjacency, colors): 
                return True 
            del state[node] 
    return False 

def main():
    nodes, adjacency, colors = get_user_input()
    if not map_coloring({}, nodes, adjacency, colors):
        print("\nNo valid coloring found.")

main()



input :

Enter number of nodes: 3
Enter node names (e.g. A, B, C):
Node: a
Node: b
Node: c
Enter adjacency list (space-separated neighbors):
Neighbors of A: b c
Neighbors of B: a c
Neighbors of C: b a
Enter colors separated by commas (e.g. Red,Green,Blue):
red,yellow,blue


